<p align="center">
  <img align="center" src="https://h.top4top.io/p_1795v4myr1.png" alt="BlackDropper" height="200px" />
</p>

# Black Binder
Simple .NET File Binder

## Features
1. Small Stub 15kb
2. Support Multiple Files

## Screenshot
![screenshot](https://j.top4top.io/p_1795k7wlf1.png)

## LEGAL DISCLAIMER PLEASE READ!
##### I, the creator and all those associated with the development and production of this program are not responsible for any actions and or damages caused by this software. You bear the full responsibility of your actions and acknowledge that this software was created for educational purposes only. This software's intended purpose is NOT to be used maliciously, or on any system that you do not have own or have explicit permission to operate and use this program on. By using this software, you automatically agree to the above.

## License
This project is licensed under the MIT License

## Copyright
BlackHacker - 2020
