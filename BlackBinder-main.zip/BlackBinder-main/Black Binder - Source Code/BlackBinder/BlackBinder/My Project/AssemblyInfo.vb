﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("Black Binder")> 
<Assembly: AssemblyDescription("Simple .NET File Binder")> 
<Assembly: AssemblyCompany("DarkSoftwareCo - Black.Hacker")> 
<Assembly: AssemblyProduct("Black Binder")> 
<Assembly: AssemblyCopyright("Copyright © DarkSoftwareCo - 2021")> 
<Assembly: AssemblyTrademark("Black Products")> 

<Assembly: ComVisible(False)>

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("56a36a2f-86d1-489a-a6ba-318d629cdb0c")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("1.0.0.0")> 
<Assembly: AssemblyFileVersion("1.0.0.0")> 
