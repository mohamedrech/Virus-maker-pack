# WIFI-ATK (wifi attacks tool kit)

<img alt="wifi-atk" src="github/icons/wifitool.png" height="20%" width="100%" />

# About
it's a powerful and effective tool for attacking Wi-Fi networks and it supports many different attacks

# Social media links
the <a href="https://www.youtube.com/@eblis-tools">youtube channel</a> and the
<a href="https://t.me/EBLISTOOLScommunity">telegram channel</a>
 
# What attacks does the tool support? ?

<ul>
 <li>Man In The Middle Attack</li>
 <li>Network Overload Attack</li>
 <li>Information Disclosure Attack</li>
 <li>WIFI Dos Attack</li>
 </ul>

# WIFI-ATK how to install and use

```
apt update
```
```
apt install git
```
```
git clone https://github.com/EBLIS-TOOLS/WIFI-ATK.git
```
```
cd WIFI-ATK
```

# How to run the tool

```
apt install python3  
```
```
pip install requirements.txt
```
```
python3 wifi-atk.py
```
# Screenshot


<img alt="wifi-atk" src="github/icons/sc.png" height="30%" width="100%" />
