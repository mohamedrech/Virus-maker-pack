![](https://img.shields.io/maintenance/no/2018)

## BlackWorm v6.0 Black Ninja
I stopped updating the software but it still works

## What's New
1. Full Data Transfer Encryption using Base64
2. Modified Icon Manager
3. Modified Plugin Manager
4. Modified Admin Checker
5. Modified Plugin Invoking
6. Modified Custom Plugin Invoking
7. DynuDNS Updater
8. NO-IP Automatic Updater
9. New About Page
10. Stable WatchDog to look after your client
11. Add to SchTask
12. Hard Install [ Stealth Mode ]
13. FileZilla Stealer
14. Clean Password Stealer [ Fixes ]
15. CPU,FireWall,Client Privileges,MUTEX Information
16. File Binder
17. Added More than 100 New Custom Icons
18. Modified Desktop Infection
19. New Port Settings
20. New MUTEX Format (bWorm[xxxxxx-12345])
21. Listview Style
22. Remove Empty Subs and Functions
23. Process Manager With Custom Colors
24. Command Shell
25. Remote Powershell
26. Remote Desktop
27. Keylogger Manager
28. RSA Encryption With 4096bit Encryption Key for the Host and Port
29. Stable File Manager With a Downloading Large Files and Arabic Names Support
30. Critical Process
31. Updating Password Plugin
32. Added Product Serial Stealer
33. Service Manager with Full-Service Controller
34. Startup Manager
35. Victim Notification with XtremeRAT Sound
36. Simple IP Tracker
37. Infect ZIP & RAR Files [ PoC ] [ UnTested ]
38. Clients Groups [ Single and Multi-Manager ]
39. Upgrade Software DotNET Framework From 2.0 to 4.0
34. Small GUI Changes
41. Small Fixes to the Socket to be more stable
42. Multi Transfer
43. Bug Fixes

## License
MIT

## Copyright
Copyright © Black.Hacker - 2019
