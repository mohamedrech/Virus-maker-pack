﻿Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Text
Imports System.Windows.Forms
Imports System.Security
Imports System.Security.Cryptography
Imports System.IO
Imports System.Net
Imports Microsoft.Win32
Imports System.Runtime.InteropServices
Imports System.Text.RegularExpressions
Public Class Form1
    Private userName As String = Environment.UserName
    Private userDir As String = "C:\Users\"
    Public Function AES_Decrypt(ByVal bytesToBeDecrypted As Byte(), ByVal passwordBytes As Byte()) As Byte()
        On Error Resume Next
        Dim decryptedBytes As Byte() = Nothing
        Dim saltBytes As Byte() = New Byte() {1, 2, 3, 4, 5, 6, 7, 8}
        Using ms As MemoryStream = New MemoryStream()
            Using AES As RijndaelManaged = New RijndaelManaged()
                AES.KeySize = 256
                AES.BlockSize = 128
                Dim key = New Rfc2898DeriveBytes(passwordBytes, saltBytes, 1000)
                AES.Key = key.GetBytes(AES.KeySize / 8)
                AES.IV = key.GetBytes(AES.BlockSize / 8)
                AES.Mode = CipherMode.CBC
                Using cs = New CryptoStream(ms, AES.CreateDecryptor(), CryptoStreamMode.Write)
                    cs.Write(bytesToBeDecrypted, 0, bytesToBeDecrypted.Length)
                    cs.Close()
                End Using
                decryptedBytes = ms.ToArray()
            End Using
        End Using
        Return decryptedBytes
    End Function
    Public Sub DecryptFile(ByVal file As String, ByVal password As String)
        On Error Resume Next
        Dim bytesToBeDecrypted As Byte() = IO.File.ReadAllBytes(file)
        Dim passwordBytes As Byte() = Encoding.UTF8.GetBytes(password)
        passwordBytes = SHA256.Create().ComputeHash(passwordBytes)
        Dim bytesDecrypted As Byte() = AES_Decrypt(bytesToBeDecrypted, passwordBytes)
        IO.File.WriteAllBytes(file, bytesDecrypted)
        Dim extension As String = System.IO.Path.GetExtension(file)
        Dim result As String = file.Substring(0, file.Length - extension.Length)
        System.IO.File.Move(file, result)
    End Sub
    Public Sub DecryptDirectory(ByVal location As String)
        On Error Resume Next
        Dim password As String = TextBox1.Text
        Dim files As String() = Directory.GetFiles(location)
        Dim childDirectories As String() = Directory.GetDirectories(location)

        For i As Integer = 0 To files.Length - 1
            Dim extension As String = Path.GetExtension(files(i))
            If extension = ".bworm" Then
                DecryptFile(files(i), password)
            End If
        Next
        For i As Integer = 0 To childDirectories.Length - 1
            DecryptDirectory(childDirectories(i))
        Next
        label3.Visible = True
    End Sub

    Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles Button1.Click
        Dim path As String = "\"
        Dim fullpath As String = userDir & userName & path
        DecryptDirectory(fullpath)
    End Sub
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class