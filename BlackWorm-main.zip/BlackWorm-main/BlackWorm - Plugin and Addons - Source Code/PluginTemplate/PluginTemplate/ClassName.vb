﻿Public Class ClassName
    Public Function BlackPlugin()
        ' Do Not Change The Function Name
    End Function
    ' Write Your Functions Here Then Call Them in BlackPlugin()
End Class
