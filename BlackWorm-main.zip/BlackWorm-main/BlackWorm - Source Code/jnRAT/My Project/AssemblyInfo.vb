﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("Black Worm")> 
<Assembly: AssemblyDescription("Black Worm .NET Controller")> 
<Assembly: AssemblyCompany("Dark Software Company")> 
<Assembly: AssemblyProduct("Black Worm")> 
<Assembly: AssemblyCopyright("Copyright © Dark Software Company - 2019")> 
<Assembly: AssemblyTrademark("")> 

<Assembly: ComVisible(False)>

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("52f980ce-2fe6-49bb-bf37-0d494faca533")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("6.0.0.0")> 
<Assembly: AssemblyFileVersion("6.0.0.0")> 
