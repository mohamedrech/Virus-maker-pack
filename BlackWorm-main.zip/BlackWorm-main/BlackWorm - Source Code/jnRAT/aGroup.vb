﻿Public Class aGroup
    Public F As Form1
    Public U As USER
    Private Sub aGroupvb_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        For Each a As String In IO.File.ReadAllLines("Groups.ini")
            Lv1.Items.Add(a.Replace("<Group>", "").Replace("</Group>", ""))
        Next
    End Sub
    Private Sub Lv1_DoubleClick(sender As Object, e As EventArgs) Handles Lv1.DoubleClick
        F.S.Send(U, F.ENB("aGroup") & F.Y & Lv1.SelectedIndices(0))
    End Sub
End Class