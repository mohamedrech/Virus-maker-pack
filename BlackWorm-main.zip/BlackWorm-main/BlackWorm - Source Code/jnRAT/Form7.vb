﻿Imports System.IO
Imports System.Reflection

Public Class Form7
    Private Sub Form7_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        RefresLV()
    End Sub

    Private Sub RemovePluginToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles RemovePluginToolStripMenuItem.Click
        On Error Resume Next
        For Each File As ListViewItem In ListView1.SelectedItems
            IO.File.Delete("plugins\" & File.SubItems(1).Text)
        Next
        RefresLV()
    End Sub
    Public Sub RefresLV()
        Try
            ListView1.Items.Clear()
            Dim li As New List(Of ListViewItem)
            Dim i As Integer = 1
            Dim files() As String = IO.Directory.GetFiles("plugins")
            For Each fn As String In files
                Dim NewItem As New ListViewItem(i)
                i = i + 1
                NewItem.SubItems.Add(fn.Split("\")(1))
                Dim Dec As String = FileVersionInfo.GetVersionInfo("plugins\" & fn.Split("\")(1)).FileDescription
                NewItem.SubItems.Add(Dec)
                Dim myFile As New FileInfo("plugins\" & fn.Split("\")(1))
                NewItem.SubItems.Add(GetFileSize(myFile.FullName))
                li.Add(NewItem)
            Next
            ListView1.Items.AddRange(DirectCast(li.ToArray, ListViewItem()))
        Catch ex As Exception
            MsgBox("Missing DLL Files !", vbCritical, "Error ):")
        End Try
    End Sub
    Public Function GetFileSize(ByVal TheFile As String) As String
        Dim DoubleBytes As Double
        If TheFile.Length = 0 Then Return ""
        If Not System.IO.File.Exists(TheFile) Then Return ""
        '---
        Dim TheSize As ULong = My.Computer.FileSystem.GetFileInfo(TheFile).Length
        Dim SizeType As String = ""
        '---
        Try
            Select Case TheSize
                Case Is >= 1099511627776
                    DoubleBytes = CDbl(TheSize / 1099511627776) 'TB
                    Return FormatNumber(DoubleBytes, 2) & " TB"
                Case 1073741824 To 1099511627775
                    DoubleBytes = CDbl(TheSize / 1073741824) 'GB
                    Return FormatNumber(DoubleBytes, 2) & " GB"
                Case 1048576 To 1073741823
                    DoubleBytes = CDbl(TheSize / 1048576) 'MB
                    Return FormatNumber(DoubleBytes, 2) & " MB"
                Case 1024 To 1048575
                    DoubleBytes = CDbl(TheSize / 1024) 'KB
                    Return FormatNumber(DoubleBytes, 2) & " KB"
                Case 0 To 1023
                    DoubleBytes = TheSize ' bytes
                    Return FormatNumber(DoubleBytes, 2) & " bytes"
                Case Else
                    Return ""
            End Select
        Catch
            Return ""
        End Try
    End Function
    Private Sub RefreshPluginsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles RefreshPluginsToolStripMenuItem.Click
        RefresLV()
    End Sub
End Class