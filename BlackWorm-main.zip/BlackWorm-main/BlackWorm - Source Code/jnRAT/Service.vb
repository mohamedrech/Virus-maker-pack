﻿Public Class Service
    Public F As Form1
    Public U As USER

    Private Sub Service_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        RunningProcessToolStripMenuItem.Text = Lv1.Items.Count & " Running Service"
    End Sub

    Private Sub PauseToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PauseToolStripMenuItem.Click
        Try
            Dim s As String = F.ENB("Control")
            For Each proc As ListViewItem In Lv1.SelectedItems
                s &= F.Y & proc.SubItems(1).Text & F.Y & F.ENB("Pause")
            Next
            F.S.Send(U, s)
        Catch ex As Exception

        End Try
        F.S.Send(U, F.ENB("sr"))
        RunningProcessToolStripMenuItem.Text = Lv1.Items.Count & " Running Service"
    End Sub

    Private Sub ResumeToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ResumeToolStripMenuItem.Click
        Try
            Dim s As String = F.ENB("Control")
            For Each proc As ListViewItem In Lv1.SelectedItems
                s &= F.Y & proc.SubItems(1).Text & F.Y & F.ENB("Resume")
            Next
            F.S.Send(U, s)
        Catch ex As Exception

        End Try
        F.S.Send(U, F.ENB("sr"))
        RunningProcessToolStripMenuItem.Text = Lv1.Items.Count & " Running Service"
    End Sub

    Private Sub StartToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles StartToolStripMenuItem.Click
        Try
            Dim s As String = F.ENB("Control")
            For Each proc As ListViewItem In Lv1.SelectedItems
                s &= F.Y & proc.SubItems(1).Text & F.Y & F.ENB("Start")
            Next
            F.S.Send(U, s)
        Catch ex As Exception

        End Try
        F.S.Send(U, F.ENB("sr"))
        RunningProcessToolStripMenuItem.Text = Lv1.Items.Count & " Running Service"
    End Sub

    Private Sub StopToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles StopToolStripMenuItem.Click
        Try
            Dim s As String = F.ENB("Control")
            For Each proc As ListViewItem In Lv1.SelectedItems
                s &= F.Y & proc.SubItems(1).Text & F.Y & F.ENB("Stop")
            Next
            F.S.Send(U, s)
        Catch ex As Exception

        End Try
        F.S.Send(U, F.ENB("sr"))
        RunningProcessToolStripMenuItem.Text = Lv1.Items.Count & " Running Service"
    End Sub

    Private Sub RefreshToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles RefreshToolStripMenuItem.Click
        RunningProcessToolStripMenuItem.Text = Lv1.Items.Count & " Running Process"
        Try
            F.S.Send(U, F.ENB("sr"))

        Catch ex As Exception

        End Try
    End Sub
End Class