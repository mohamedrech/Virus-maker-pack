﻿Public Class pr
    Public F As Form1
    Public U As USER
    Private Sub RefreshToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles RefreshToolStripMenuItem.Click
        RunningProcessToolStripMenuItem.Text = prlist.Items.Count & " Running Process"
        Try
            F.S.Send(U, F.ENB("pr"))

        Catch ex As Exception

        End Try

    End Sub

    Private Sub KillToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles KillToolStripMenuItem.Click
        Try
            Dim s As String = F.ENB("kill")
            For Each proc As ListViewItem In prlist.SelectedItems
                s &= F.Y & proc.SubItems(1).Text
            Next
            F.S.Send(U, s)
        Catch ex As Exception

        End Try
        F.S.Send(U, F.ENB("pr"))
        RunningProcessToolStripMenuItem.Text = prlist.Items.Count & " Running Process"
    End Sub

    Private Sub pr_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        RunningProcessToolStripMenuItem.Text = prlist.Items.Count & " Running Process"
    End Sub
End Class