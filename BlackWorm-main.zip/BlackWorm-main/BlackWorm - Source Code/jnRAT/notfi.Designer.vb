﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class notfi
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(notfi))
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.IMG2 = New System.Windows.Forms.ImageList(Me.components)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.DeepSkyBlue
        Me.Label5.Location = New System.Drawing.Point(36, 102)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(40, 13)
        Me.Label5.TabIndex = 79
        Me.Label5.Text = "Label5"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.DeepSkyBlue
        Me.Label4.Location = New System.Drawing.Point(62, 85)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(40, 13)
        Me.Label4.TabIndex = 78
        Me.Label4.Text = "Label4"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.DeepSkyBlue
        Me.Label1.Location = New System.Drawing.Point(30, 51)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(40, 13)
        Me.Label1.TabIndex = 75
        Me.Label1.Text = "Label1"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.ForeColor = System.Drawing.Color.White
        Me.Label17.Location = New System.Drawing.Point(10, 102)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(28, 13)
        Me.Label17.TabIndex = 74
        Me.Label17.Text = "OS :"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.DeepSkyBlue
        Me.Label3.Location = New System.Drawing.Point(44, 68)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(40, 13)
        Me.Label3.TabIndex = 77
        Me.Label3.Text = "Label3"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.DeepSkyBlue
        Me.Label2.Location = New System.Drawing.Point(32, 34)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(40, 13)
        Me.Label2.TabIndex = 76
        Me.Label2.Text = "Label2"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.ForeColor = System.Drawing.Color.White
        Me.Label16.Location = New System.Drawing.Point(10, 85)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(54, 13)
        Me.Label16.TabIndex = 73
        Me.Label16.Text = "Country :"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.ForeColor = System.Drawing.Color.White
        Me.Label15.Location = New System.Drawing.Point(10, 68)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(36, 13)
        Me.Label15.TabIndex = 72
        Me.Label15.Text = "User :"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.ForeColor = System.Drawing.Color.White
        Me.Label14.Location = New System.Drawing.Point(10, 51)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(22, 13)
        Me.Label14.TabIndex = 71
        Me.Label14.Text = "IP :"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.Color.White
        Me.Label12.Location = New System.Drawing.Point(10, 34)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(24, 13)
        Me.Label12.TabIndex = 70
        Me.Label12.Text = "ID :"
        '
        'Timer1
        '
        '
        'PictureBox1
        '
        Me.PictureBox1.Dock = System.Windows.Forms.DockStyle.Top
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(0, 0)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(256, 31)
        Me.PictureBox1.TabIndex = 80
        Me.PictureBox1.TabStop = False
        '
        'PictureBox2
        '
        Me.PictureBox2.Location = New System.Drawing.Point(228, 33)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(27, 14)
        Me.PictureBox2.TabIndex = 81
        Me.PictureBox2.TabStop = False
        '
        'IMG2
        '
        Me.IMG2.ImageStream = CType(resources.GetObject("IMG2.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.IMG2.TransparentColor = System.Drawing.Color.Transparent
        Me.IMG2.Images.SetKeyName(0, "ABW.png")
        Me.IMG2.Images.SetKeyName(1, "AFG.png")
        Me.IMG2.Images.SetKeyName(2, "AGO.png")
        Me.IMG2.Images.SetKeyName(3, "AIA.png")
        Me.IMG2.Images.SetKeyName(4, "ALB.png")
        Me.IMG2.Images.SetKeyName(5, "AND.png")
        Me.IMG2.Images.SetKeyName(6, "ARE.png")
        Me.IMG2.Images.SetKeyName(7, "ARG.png")
        Me.IMG2.Images.SetKeyName(8, "ARM.png")
        Me.IMG2.Images.SetKeyName(9, "ASM.png")
        Me.IMG2.Images.SetKeyName(10, "ATF.png")
        Me.IMG2.Images.SetKeyName(11, "ATG.png")
        Me.IMG2.Images.SetKeyName(12, "AUS.png")
        Me.IMG2.Images.SetKeyName(13, "AUT.png")
        Me.IMG2.Images.SetKeyName(14, "ax.png")
        Me.IMG2.Images.SetKeyName(15, "AZE.png")
        Me.IMG2.Images.SetKeyName(16, "BDI.png")
        Me.IMG2.Images.SetKeyName(17, "BEL.png")
        Me.IMG2.Images.SetKeyName(18, "BEN.png")
        Me.IMG2.Images.SetKeyName(19, "BFA.png")
        Me.IMG2.Images.SetKeyName(20, "BGD.png")
        Me.IMG2.Images.SetKeyName(21, "BGR.png")
        Me.IMG2.Images.SetKeyName(22, "BHR.png")
        Me.IMG2.Images.SetKeyName(23, "BHS.png")
        Me.IMG2.Images.SetKeyName(24, "BIH.png")
        Me.IMG2.Images.SetKeyName(25, "BLR.png")
        Me.IMG2.Images.SetKeyName(26, "BLZ.png")
        Me.IMG2.Images.SetKeyName(27, "BMU.png")
        Me.IMG2.Images.SetKeyName(28, "BOL.png")
        Me.IMG2.Images.SetKeyName(29, "BRA.png")
        Me.IMG2.Images.SetKeyName(30, "BRB.png")
        Me.IMG2.Images.SetKeyName(31, "BRN.png")
        Me.IMG2.Images.SetKeyName(32, "BTN.png")
        Me.IMG2.Images.SetKeyName(33, "BVT.png")
        Me.IMG2.Images.SetKeyName(34, "BWA.png")
        Me.IMG2.Images.SetKeyName(35, "CAF.png")
        Me.IMG2.Images.SetKeyName(36, "CAN.png")
        Me.IMG2.Images.SetKeyName(37, "CCK.png")
        Me.IMG2.Images.SetKeyName(38, "CHE.png")
        Me.IMG2.Images.SetKeyName(39, "CHL.png")
        Me.IMG2.Images.SetKeyName(40, "CHN.png")
        Me.IMG2.Images.SetKeyName(41, "CIV.png")
        Me.IMG2.Images.SetKeyName(42, "CMR.png")
        Me.IMG2.Images.SetKeyName(43, "COD.png")
        Me.IMG2.Images.SetKeyName(44, "COG.png")
        Me.IMG2.Images.SetKeyName(45, "COK.png")
        Me.IMG2.Images.SetKeyName(46, "COL.png")
        Me.IMG2.Images.SetKeyName(47, "COM.png")
        Me.IMG2.Images.SetKeyName(48, "CPV.png")
        Me.IMG2.Images.SetKeyName(49, "CRI.png")
        Me.IMG2.Images.SetKeyName(50, "cs.png")
        Me.IMG2.Images.SetKeyName(51, "CUB.png")
        Me.IMG2.Images.SetKeyName(52, "CXR.png")
        Me.IMG2.Images.SetKeyName(53, "CYM.png")
        Me.IMG2.Images.SetKeyName(54, "CYP.png")
        Me.IMG2.Images.SetKeyName(55, "CZE.png")
        Me.IMG2.Images.SetKeyName(56, "DEU.png")
        Me.IMG2.Images.SetKeyName(57, "DJI.png")
        Me.IMG2.Images.SetKeyName(58, "DMA.png")
        Me.IMG2.Images.SetKeyName(59, "DNK.png")
        Me.IMG2.Images.SetKeyName(60, "DOM.png")
        Me.IMG2.Images.SetKeyName(61, "DZA.png")
        Me.IMG2.Images.SetKeyName(62, "ECU.png")
        Me.IMG2.Images.SetKeyName(63, "EGY.png")
        Me.IMG2.Images.SetKeyName(64, "england.png")
        Me.IMG2.Images.SetKeyName(65, "ERI.png")
        Me.IMG2.Images.SetKeyName(66, "ESH.png")
        Me.IMG2.Images.SetKeyName(67, "ESP.png")
        Me.IMG2.Images.SetKeyName(68, "EST.png")
        Me.IMG2.Images.SetKeyName(69, "ETH.png")
        Me.IMG2.Images.SetKeyName(70, "FIN.png")
        Me.IMG2.Images.SetKeyName(71, "FJI.png")
        Me.IMG2.Images.SetKeyName(72, "FLK.png")
        Me.IMG2.Images.SetKeyName(73, "FRA.png")
        Me.IMG2.Images.SetKeyName(74, "FRO.png")
        Me.IMG2.Images.SetKeyName(75, "FSM.png")
        Me.IMG2.Images.SetKeyName(76, "GAB.png")
        Me.IMG2.Images.SetKeyName(77, "GBR.png")
        Me.IMG2.Images.SetKeyName(78, "GEO.png")
        Me.IMG2.Images.SetKeyName(79, "GHA.png")
        Me.IMG2.Images.SetKeyName(80, "GIB.png")
        Me.IMG2.Images.SetKeyName(81, "GIN.png")
        Me.IMG2.Images.SetKeyName(82, "GLP.png")
        Me.IMG2.Images.SetKeyName(83, "GMB.png")
        Me.IMG2.Images.SetKeyName(84, "GNB.png")
        Me.IMG2.Images.SetKeyName(85, "GNQ.png")
        Me.IMG2.Images.SetKeyName(86, "GRC.png")
        Me.IMG2.Images.SetKeyName(87, "GRD.png")
        Me.IMG2.Images.SetKeyName(88, "GRL.png")
        Me.IMG2.Images.SetKeyName(89, "GTM.png")
        Me.IMG2.Images.SetKeyName(90, "GUF.png")
        Me.IMG2.Images.SetKeyName(91, "GUM.png")
        Me.IMG2.Images.SetKeyName(92, "GUY.png")
        Me.IMG2.Images.SetKeyName(93, "HKG.png")
        Me.IMG2.Images.SetKeyName(94, "HMD.png")
        Me.IMG2.Images.SetKeyName(95, "HND.png")
        Me.IMG2.Images.SetKeyName(96, "HRV.png")
        Me.IMG2.Images.SetKeyName(97, "HTI.png")
        Me.IMG2.Images.SetKeyName(98, "HUN.png")
        Me.IMG2.Images.SetKeyName(99, "IDN.png")
        Me.IMG2.Images.SetKeyName(100, "IND.png")
        Me.IMG2.Images.SetKeyName(101, "IOT.png")
        Me.IMG2.Images.SetKeyName(102, "IRL.png")
        Me.IMG2.Images.SetKeyName(103, "IRN.png")
        Me.IMG2.Images.SetKeyName(104, "IRQ.png")
        Me.IMG2.Images.SetKeyName(105, "ISL.png")
        Me.IMG2.Images.SetKeyName(106, "ISR.png")
        Me.IMG2.Images.SetKeyName(107, "ITA.png")
        Me.IMG2.Images.SetKeyName(108, "JAM.png")
        Me.IMG2.Images.SetKeyName(109, "JOR.png")
        Me.IMG2.Images.SetKeyName(110, "JPN.png")
        Me.IMG2.Images.SetKeyName(111, "KAZ.png")
        Me.IMG2.Images.SetKeyName(112, "KEN.png")
        Me.IMG2.Images.SetKeyName(113, "KGZ.png")
        Me.IMG2.Images.SetKeyName(114, "KHM.png")
        Me.IMG2.Images.SetKeyName(115, "KIR.png")
        Me.IMG2.Images.SetKeyName(116, "KNA.png")
        Me.IMG2.Images.SetKeyName(117, "KOR.png")
        Me.IMG2.Images.SetKeyName(118, "KWT.png")
        Me.IMG2.Images.SetKeyName(119, "LAO.png")
        Me.IMG2.Images.SetKeyName(120, "LBN.png")
        Me.IMG2.Images.SetKeyName(121, "LBR.png")
        Me.IMG2.Images.SetKeyName(122, "LBY.png")
        Me.IMG2.Images.SetKeyName(123, "LCA.png")
        Me.IMG2.Images.SetKeyName(124, "LIE.png")
        Me.IMG2.Images.SetKeyName(125, "LKA.png")
        Me.IMG2.Images.SetKeyName(126, "LSO.png")
        Me.IMG2.Images.SetKeyName(127, "LTU.png")
        Me.IMG2.Images.SetKeyName(128, "LUX.png")
        Me.IMG2.Images.SetKeyName(129, "LVA.png")
        Me.IMG2.Images.SetKeyName(130, "MAC.png")
        Me.IMG2.Images.SetKeyName(131, "MAR.png")
        Me.IMG2.Images.SetKeyName(132, "MCO.png")
        Me.IMG2.Images.SetKeyName(133, "MDA.png")
        Me.IMG2.Images.SetKeyName(134, "MDG.png")
        Me.IMG2.Images.SetKeyName(135, "MDV.png")
        Me.IMG2.Images.SetKeyName(136, "MEX.png")
        Me.IMG2.Images.SetKeyName(137, "MHL.png")
        Me.IMG2.Images.SetKeyName(138, "MKD.png")
        Me.IMG2.Images.SetKeyName(139, "MLI.png")
        Me.IMG2.Images.SetKeyName(140, "MLT.png")
        Me.IMG2.Images.SetKeyName(141, "MMR.png")
        Me.IMG2.Images.SetKeyName(142, "MNE.png")
        Me.IMG2.Images.SetKeyName(143, "MNG.png")
        Me.IMG2.Images.SetKeyName(144, "MNP.png")
        Me.IMG2.Images.SetKeyName(145, "MOZ.png")
        Me.IMG2.Images.SetKeyName(146, "MRT.png")
        Me.IMG2.Images.SetKeyName(147, "MSR.png")
        Me.IMG2.Images.SetKeyName(148, "MSY.png")
        Me.IMG2.Images.SetKeyName(149, "MTQ.png")
        Me.IMG2.Images.SetKeyName(150, "MUS.png")
        Me.IMG2.Images.SetKeyName(151, "MWI.png")
        Me.IMG2.Images.SetKeyName(152, "MYT.png")
        Me.IMG2.Images.SetKeyName(153, "NAM.png")
        Me.IMG2.Images.SetKeyName(154, "NCL.png")
        Me.IMG2.Images.SetKeyName(155, "NER.png")
        Me.IMG2.Images.SetKeyName(156, "NFK.png")
        Me.IMG2.Images.SetKeyName(157, "NGA.png")
        Me.IMG2.Images.SetKeyName(158, "NIC.png")
        Me.IMG2.Images.SetKeyName(159, "NIU.png")
        Me.IMG2.Images.SetKeyName(160, "NLD.png")
        Me.IMG2.Images.SetKeyName(161, "NOR.png")
        Me.IMG2.Images.SetKeyName(162, "NPL.png")
        Me.IMG2.Images.SetKeyName(163, "NRU.png")
        Me.IMG2.Images.SetKeyName(164, "NZL.png")
        Me.IMG2.Images.SetKeyName(165, "OMN.png")
        Me.IMG2.Images.SetKeyName(166, "PAK.png")
        Me.IMG2.Images.SetKeyName(167, "PAN.png")
        Me.IMG2.Images.SetKeyName(168, "PCN.png")
        Me.IMG2.Images.SetKeyName(169, "PER.png")
        Me.IMG2.Images.SetKeyName(170, "PHL.png")
        Me.IMG2.Images.SetKeyName(171, "PLW.png")
        Me.IMG2.Images.SetKeyName(172, "PNG.png")
        Me.IMG2.Images.SetKeyName(173, "POL.png")
        Me.IMG2.Images.SetKeyName(174, "PRI.png")
        Me.IMG2.Images.SetKeyName(175, "PRK.png")
        Me.IMG2.Images.SetKeyName(176, "PRT.png")
        Me.IMG2.Images.SetKeyName(177, "PRY.png")
        Me.IMG2.Images.SetKeyName(178, "PSE.png")
        Me.IMG2.Images.SetKeyName(179, "PYF.png")
        Me.IMG2.Images.SetKeyName(180, "QAT.png")
        Me.IMG2.Images.SetKeyName(181, "REU.png")
        Me.IMG2.Images.SetKeyName(182, "ROM.png")
        Me.IMG2.Images.SetKeyName(183, "RUS.png")
        Me.IMG2.Images.SetKeyName(184, "RWA.png")
        Me.IMG2.Images.SetKeyName(185, "SAU.png")
        Me.IMG2.Images.SetKeyName(186, "scotland.png")
        Me.IMG2.Images.SetKeyName(187, "SDN.png")
        Me.IMG2.Images.SetKeyName(188, "SEN.png")
        Me.IMG2.Images.SetKeyName(189, "SGP.png")
        Me.IMG2.Images.SetKeyName(190, "SGS.png")
        Me.IMG2.Images.SetKeyName(191, "SHN.png")
        Me.IMG2.Images.SetKeyName(192, "SJM.png")
        Me.IMG2.Images.SetKeyName(193, "SLB.png")
        Me.IMG2.Images.SetKeyName(194, "SLE.png")
        Me.IMG2.Images.SetKeyName(195, "SLV.png")
        Me.IMG2.Images.SetKeyName(196, "SMR.png")
        Me.IMG2.Images.SetKeyName(197, "SOM.png")
        Me.IMG2.Images.SetKeyName(198, "SPM.png")
        Me.IMG2.Images.SetKeyName(199, "SRB.png")
        Me.IMG2.Images.SetKeyName(200, "STP.png")
        Me.IMG2.Images.SetKeyName(201, "SUR.png")
        Me.IMG2.Images.SetKeyName(202, "SVK.png")
        Me.IMG2.Images.SetKeyName(203, "SVN.png")
        Me.IMG2.Images.SetKeyName(204, "SWE.png")
        Me.IMG2.Images.SetKeyName(205, "SWZ.png")
        Me.IMG2.Images.SetKeyName(206, "SYC.png")
        Me.IMG2.Images.SetKeyName(207, "SYR.png")
        Me.IMG2.Images.SetKeyName(208, "TCA.png")
        Me.IMG2.Images.SetKeyName(209, "TCD.png")
        Me.IMG2.Images.SetKeyName(210, "TGO.png")
        Me.IMG2.Images.SetKeyName(211, "THA.png")
        Me.IMG2.Images.SetKeyName(212, "TJK.png")
        Me.IMG2.Images.SetKeyName(213, "TKL.png")
        Me.IMG2.Images.SetKeyName(214, "TKM.png")
        Me.IMG2.Images.SetKeyName(215, "TLS.png")
        Me.IMG2.Images.SetKeyName(216, "TON.png")
        Me.IMG2.Images.SetKeyName(217, "TTO.png")
        Me.IMG2.Images.SetKeyName(218, "TUN.png")
        Me.IMG2.Images.SetKeyName(219, "TUR.png")
        Me.IMG2.Images.SetKeyName(220, "TUV.png")
        Me.IMG2.Images.SetKeyName(221, "TWN.png")
        Me.IMG2.Images.SetKeyName(222, "TZA.png")
        Me.IMG2.Images.SetKeyName(223, "UGA.png")
        Me.IMG2.Images.SetKeyName(224, "UKR.png")
        Me.IMG2.Images.SetKeyName(225, "UMI.png")
        Me.IMG2.Images.SetKeyName(226, "URY.png")
        Me.IMG2.Images.SetKeyName(227, "USA.png")
        Me.IMG2.Images.SetKeyName(228, "UZB.png")
        Me.IMG2.Images.SetKeyName(229, "VAT.png")
        Me.IMG2.Images.SetKeyName(230, "VCT.png")
        Me.IMG2.Images.SetKeyName(231, "VEN.png")
        Me.IMG2.Images.SetKeyName(232, "VGB.png")
        Me.IMG2.Images.SetKeyName(233, "VIR.png")
        Me.IMG2.Images.SetKeyName(234, "VNM.png")
        Me.IMG2.Images.SetKeyName(235, "VUT.png")
        Me.IMG2.Images.SetKeyName(236, "WLF.png")
        Me.IMG2.Images.SetKeyName(237, "WSM.png")
        Me.IMG2.Images.SetKeyName(238, "X.png")
        Me.IMG2.Images.SetKeyName(239, "YEM.png")
        Me.IMG2.Images.SetKeyName(240, "ZAF.png")
        Me.IMG2.Images.SetKeyName(241, "ZMB.png")
        Me.IMG2.Images.SetKeyName(242, "ZWE.png")
        '
        'notfi
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.ClientSize = New System.Drawing.Size(256, 124)
        Me.ControlBox = False
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label12)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "notfi"
        Me.Opacity = 0.85R
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.Text = "notfi"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents IMG2 As System.Windows.Forms.ImageList
End Class
