﻿Public Class SM
    Public F As Form1
    Public U As USER
    Private Sub SM_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        RunningProcessToolStripMenuItem.Text = smlist.Items.Count & " Startup Items"
    End Sub

    Private Sub RefreshToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles RefreshToolStripMenuItem.Click

        If GetLocalItemsToolStripMenuItem.Enabled = False Then
            RunningProcessToolStripMenuItem.Text = smlist.Items.Count & Lv1.Items.Count & " Startup Items"
            Try
                F.S.Send(U, F.ENB("sm"))
                F.S.Send(U, F.ENB("sml"))

            Catch ex As Exception

            End Try
        Else
            RunningProcessToolStripMenuItem.Text = smlist.Items.Count & " Startup Items"
            F.S.Send(U, F.ENB("sm"))
        End If
    End Sub

    Private Sub KillToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles KillToolStripMenuItem.Click
        Try
            Dim s As String = F.ENB("del")
            For Each proc As ListViewItem In smlist.SelectedItems
                s &= F.Y & proc.SubItems(0).Text
            Next
            F.S.Send(U, s)
        Catch ex As Exception

        End Try
        If GetLocalItemsToolStripMenuItem.Enabled = False Then
            RunningProcessToolStripMenuItem.Text = smlist.Items.Count & Lv1.Items.Count & " Startup Items"
            Try
                F.S.Send(U, F.ENB("sm"))
                F.S.Send(U, F.ENB("sml"))

            Catch ex As Exception

            End Try
        Else
            RunningProcessToolStripMenuItem.Text = smlist.Items.Count & " Startup Items"
            F.S.Send(U, F.ENB("sm"))
        End If
    End Sub

    Private Sub GetLocalItemsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles GetLocalItemsToolStripMenuItem.Click
        F.S.Send(U, F.ENB("sml"))
        RunningProcessToolStripMenuItem.Text = smlist.Items.Count + Lv1.Items.Count & " Startup Items"
        System.Threading.Thread.Sleep(2000)
        If Lv1.Items.Count = 0 Then
            GetLocalItemsToolStripMenuItem.Enabled = True
        Else
            GetLocalItemsToolStripMenuItem.Enabled = False
        End If
    End Sub
End Class