﻿Public Class bkMenu
  
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If ComboBox1.SelectedIndex = 0 Then
            'CODE == 0
            exploitpack.Show()
            Me.Close()

        ElseIf ComboBox1.SelectedIndex = 1 Then

            'CODE == 1
            Dim webAddress As String = "http://www.f2ko.de/en/ob2e.php"
            Process.Start(webAddress)

        ElseIf ComboBox1.SelectedIndex = 2 Then
            'CODE == 2

            Process.Start("Easy Binder.exe")

        ElseIf ComboBox1.SelectedIndex = 3 Then
            'CODE == 3

            bkUpdate.Show()
            Me.Close()

        End If

    End Sub
End Class