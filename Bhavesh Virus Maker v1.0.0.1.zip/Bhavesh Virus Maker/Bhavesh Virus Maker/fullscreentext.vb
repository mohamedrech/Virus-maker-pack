﻿Public Class fullscreentext

    Private Sub fullscreentext_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.WindowState = FormWindowState.Maximized
        RichTextBox1.Text = exploitpack.codewindow.Text
    End Sub
End Class