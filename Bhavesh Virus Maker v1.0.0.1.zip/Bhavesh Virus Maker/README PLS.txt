This is the full source-code, so you can edit it if you have the required things.


		HOW TO RUN ?
1) Open "Bhavesh Virus Maker''
2) Goto "Bin"
3) Goto "Debug"
4) Run "Bhavesh Virus Maker.exe"


		REQUIREMENTS - TO RUN
1) Microsoft.NET Framework 4.5
2) Windows Operating System

		REQUIREMENTS - TO EDIT SOURCE
1) Microsoft Visual Studio 2010/12/13/15
OR
2) SharpDevelop 4.0

		ANTIVIRUS DETECTS?
1) Close Antivirus Protection
2) Stop Real-Time protection

		WHY DETECTS AS VIRUS?
Because it is a virus making tool. If you see the source, you will understanf why ;)


THANKYOU FOR DOWNLOADING!
NEW CHANGES WILL COME WITH FUTURE UPDATES.
BYE!		