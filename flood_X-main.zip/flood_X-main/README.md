# flood_X
# A Tool Created By GURU 
Do DDOS ATTACK ON ANY PHONES IP MAKE THE PHONE GET FORMATE
This is udp socket packets send in a bulk form you can can hang and
Format anyone android device just by using his ip
# USE IT IN YOUR OWN RISK.🔥
