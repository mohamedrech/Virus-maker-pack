# darkside
Darkside Ransomware

Caution: This is malware, real ransomware that can destroy your system. For research purposes only. Download at your own risk. We are not responsbile for what you do with these files.

| Filename                                                     | MD5 Hash                         | SHA1 Hash                                | SHA256 Hash                                                  | VirusTotal                                                   |
| ------------------------------------------------------------ | -------------------------------- | ---------------------------------------- | ------------------------------------------------------------ | ------------------------------------------------------------ |
| acer.exe                                                     | 979692cd7fc638beea6e9d68c752f360 | c511ae4d80aaa281c610190aa13630de61ca714c | 0a0c225f0e5ee941a79f2b7701f1285e4975a2859eb4d025d96d9e366e81abb9 | https://www.virustotal.com/gui/file/0a0c225f0e5ee941a79f2b7701f1285e4975a2859eb4d025d96d9e366e81abb9/details |
| 151fbd6c299e734f7853497bd083abfa29f8c186a9db31dbe330ace2d35660d5 | 9d418ecc0f3bf45029263b0944236884 | eeb28144f39b275ee1ec008859e80f215710dc57 | 151fbd6c299e734f7853497bd083abfa29f8c186a9db31dbe330ace2d35660d5 | https://www.virustotal.com/gui/file/151fbd6c299e734f7853497bd083abfa29f8c186a9db31dbe330ace2d35660d5/detection |
| N/A                                                          | 04fde4340cc79cd9e61340d4c1e8ddfb | 88fc623483f7ffe57f986ed10789e6723083fcd8 | 8cfd28911878af048fb96b6cc0b9da770542576d5c2b20b193c3cfc4bde4d3bc | https://www.virustotal.com/gui/file/8cfd28911878af048fb96b6cc0b9da770542576d5c2b20b193c3cfc4bde4d3bc/details |
| N/A                                                          | f587adbd83ff3f4d2985453cd45c7ab1 | 2715340f82426f840cf7e460f53a36fc3aad52aa | 156335b95ba216456f1ac0894b7b9d6ad95404ac7df447940f21646ca0090673 | https://www.virustotal.com/gui/file/156335b95ba216456f1ac0894b7b9d6ad95404ac7df447940f21646ca0090673/detection |

Password: Infected

Other Samples (11/25/2020-05/01/2021): https://bazaar.abuse.ch/browse/tag/DarkSide/

